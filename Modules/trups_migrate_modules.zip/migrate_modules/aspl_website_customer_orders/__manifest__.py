# -*- coding: utf-8 -*-
##############################################################################
# Author      : Acespritech Solutions Pvt. Ltd. (<www.acespritech.com>)
# Copyright(c): 2012-Present Acespritech Solutions Pvt. Ltd.
# All Rights Reserved.
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
##############################################################################

{
    'name': "Website Customer Orders (Community)",
    'category': 'website',
    'description': """
        Website Customer Orders provides a view to see all sale orders
    """,
    'price': 30,
    'currency': 'EUR',
    'author': "Acespritech Solutions Pvt. Ltd.",
    'website': 'http://www.acespritech.com',
    'version': "17.0",
    'depends': ['base', 'web', 'website_sale', 'sale_management', 'uom'],
    'images': ['static/description/website_customer_order.png'],
    'data': [
        'security/ir.model.access.csv',
        'views/my_order_template.xml',
        'views/view_orders_template.xml',
    ],
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3'

}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
