# -*- coding: utf-8 -*-
##############################################################################
# Author      : Acespritech Solutions Pvt. Ltd. (<www.acespritech.com>)
# Copyright(c): 2012-Present Acespritech Solutions Pvt. Ltd.
# All Rights Reserved.
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
##############################################################################

from odoo.http import request

from odoo import http, _


class MyOrders(http.Controller):
    @http.route('/my/order', type='http', auth='public', website=True)
    def render_my_order_page(self, sortby=None):
        '''
        open my order page and we can see all sale orders.
        '''
        searchbar_sortings = {
            'date_desc': {'label': _('Order Date >'),
                          'order': 'date_order desc'},
            'date': {'label': _('Order Date <'), 'order': 'date_order'},
        }
        if not sortby:
            sortby = 'date'
        sort_order = searchbar_sortings[sortby]['order']
        orders = request.env['sale.order'].search(
            [('partner_id', '=', request.env.user.partner_id.id)],
            order=sort_order)
        return request.render(
            'aspl_website_customer_orders.view_orders', {
                'orders': orders,
                'searchbar_sortings': searchbar_sortings, 'sortby': sortby})

    @http.route(['/add/cart', '/shop/buy_now'], type='http', auth="public", website=True)
    def repeat_sale_order_cart(self, **kwargs):
        '''When you click add to cart button it will add that product to your cart if that product is already in cart it will update quantity.'''
        url = request.httprequest.url
        check_url = url.split('/', 3)
        check_route_url = check_url[-1].split('?')
        string_url = 'add/cart'
        order_id = kwargs.get('id')
        new_order_id = request.env['sale.order.line'].sudo().browse(
            int(order_id))
        sale_order = request.website.sale_get_order(force_create=True)
        if sale_order.state != 'draft':
            request.session['sale_order_id'] = None
            sale_order = request.website.sale_get_order(force_create=True)
        add_qty = 0
        set_qty = 0
        if sale_order.order_line:
            for line in sale_order.order_line:
                if line.product_id:
                    if line.product_id == new_order_id.product_id:
                        add_qty = line.product_uom_qty + new_order_id.product_uom_qty
                        set_qty = add_qty
                        break
                    else:
                        add_qty = new_order_id.product_uom_qty
                        set_qty = add_qty
                else:
                    add_qty = new_order_id.product_uom_qty
                    set_qty = add_qty
            sale_order._cart_update(
                    product_id=int(new_order_id.product_id.id),
                    add_qty=add_qty,
                    set_qty=set_qty,
                    )
        else:
            sale_order._cart_update(
                product_id=int(new_order_id.product_id.id),
                add_qty=new_order_id.product_uom_qty,
                set_qty=new_order_id.product_uom_qty,
            )
        if string_url in check_route_url:
            return request.redirect("/my/order")
        else:
            return request.redirect("/shop/cart")

    @http.route('/order/again', type='http', auth="public", website=True)
    def sale_order_again(self, **kwargs):
        '''When you click on order again button it will add all items in sale order and redirect to your cart.'''
        order_id = kwargs.get('id')
        repeat_order_id = request.env['sale.order'].sudo().browse(
            int(order_id))
        sale_order = request.website.sale_get_order(force_create=True)
        if sale_order.state != 'draft':
            request.session['sale_order_id'] = None
            sale_order = request.website.sale_get_order(force_create=True)
        add_qty = 0
        set_qty = 0
        for record_line in repeat_order_id.order_line:
            if record_line.product_id and sale_order.order_line:
                for line_record in sale_order.order_line:
                    if line_record.product_id == record_line.product_id:
                        add_qty = record_line.product_uom_qty + line_record.product_uom_qty
                        set_qty = add_qty
                        break
                    else:
                        add_qty = record_line.product_uom_qty
                        set_qty = add_qty
            else:
                add_qty = record_line.product_uom_qty
                set_qty = add_qty

            sale_order._cart_update(
                product_id=int(record_line.product_id.id),
                add_qty=add_qty,
                set_qty=set_qty,
            )
        return request.redirect("/shop/cart")

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: