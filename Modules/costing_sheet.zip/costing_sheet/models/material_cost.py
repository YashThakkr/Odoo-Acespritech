from odoo import models, fields, api, _
from odoo.exceptions import UserError
import math

from odoo.exceptions import ValidationError

class MaterialSheet(models.Model):
    _name = "material.sheet"
    _description = "costing sheet for material before quotation"

    name = fields.Char('Name', index=True, required=True, readonly=True, copy=False, default="New")
    currency_id = fields.Many2one("res.currency", related="cost_id.currency_id")
    
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", 'New') == "New":
                vals['name'] = self.env['ir.sequence'].next_by_code('seq.material.sheet') or 'New'
        cost = super(MaterialSheet, self).create(vals_list)
        return cost

    cost_id = fields.Many2one("cost.sheet", string="Cost Sheet")
    lead_id = fields.Many2one("crm.lead", related="cost_id.lead_id")
    sheet_rev = fields.Char(related="cost_id.revision")
    project_name = fields.Char(related="cost_id.project_name")
    project_type = fields.Many2one(related="cost_id.project_type")
    discount = fields.Float("Discount %", inverse="update_summary_lines")
    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,
                                 default=lambda self: self.env.company)
    line_ids = fields.One2many("material.sheet.line", "material_id", "Lines")
    po_ids = fields.One2many("purchase.order", "material_sheet_id")
    po_count = fields.Integer("PO Count", compute="_compute_po_count")
    
    def _compute_po_count(self):
        for rec in self:
            rec.po_count = len(rec.po_ids.ids)
        
    def get_rfq(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Purchase Orders',
            'view_mode': 'tree,form',
            'view_type': 'form',
            'res_model': 'purchase.order',
            'domain': [('id', 'in', self.po_ids.ids)],
        }
    
    
    def update_summary_lines(self):
        total_net,total_dicount, total_land, total_oh_cost, total_selling_price = 0, 0, 0, 0,0
        cost = self.env["cost.sheet"].search([("id", "=", self.cost_id.id)])
        if cost:
            sheet_line = self.env["material.sheet.line"].search([("material_id", "=", self.id)])
            disc = sheet_line.material_id.discount /100
            for line in sheet_line:
                line_data = self.env["material.line.data"].search([("material_sheet_id", "=", line.id)])
                for data in line_data:
                    total_net += data.total_price
                    total_land += data.total_landed_price
                    total_oh_cost += data.total_oh_cost
                    total_selling_price += data.final_total
                    total_dicount +=  (data.final_total*disc)
            fetch_summary = self.env["cost.sheet.summary"].search(
                    [("cost_id", "=", cost.id), ("name", "=", "Material")])
            if not fetch_summary:
                self.env["cost.sheet.summary"].create(
                    {"cost_id": cost.id, "name": "Material", "net_cost": total_net,
                     "land_cost": total_land, "overhead": total_oh_cost - total_land,
                     "land_oh_cost": total_land + (total_oh_cost - total_land),
                     "selling_price": total_selling_price, "discount": total_dicount,
                     "net_price": total_selling_price - total_dicount,
                     'seq':2,
                     "net_profit": (total_selling_price - total_dicount) - (
                             total_oh_cost - total_land) - total_land})
            else:
                fetch_summary.write({ "net_cost": total_net,"land_cost": total_land, "overhead": total_oh_cost - total_land,
                  "land_oh_cost": total_land + (total_oh_cost - total_land),
                  "selling_price": total_selling_price, "discount": total_dicount,
                  "net_price": total_selling_price - total_dicount,
                  "net_profit": (total_selling_price - total_dicount) - (total_oh_cost - total_land) - total_land})
                    
        cost.update_summary()
        

    def write(self, values):
        res = super(MaterialSheet, self).write(values)
        """Override default Odoo write function and extend."""
        # Do your custom logic here
        self.update_summary_lines()
        return res


class MaterialSheetLine(models.Model):
    _name = "material.sheet.line"
    _description = "material sheet line data"

    @api.model_create_multi
    def create(self, vals_list):
        return super(MaterialSheetLine, self).create(vals_list)

    material_id = fields.Many2one("material.sheet", string="Material Sheet", ondelete='cascade')
    attachment_ids = fields.Many2many("ir.attachment",string="Attachments")
    system_id = fields.Many2one("system.system", string="System", ondelete='cascade')
    company_id = fields.Many2one(related='material_id.company_id', string='Company', store=True, readonly=True,
                                 index=True)

    @api.model
    def _get_groups(self):
        for rec in self:
            system_id = rec.system_id.id
            groups = rec.env["system.group"].search([("system_id", "=", system_id)])
            if groups:
                group_ids = [group.id for group in groups]
                return [('id', 'in', group_ids)]
            return [('id', 'in', [])]

    group_id = fields.Many2one("system.group", string="Group", domain=lambda self: self._get_groups)
    line_ids = fields.One2many("material.line.data", "material_sheet_id", "Lines")
    currency_id = fields.Many2one("res.currency", related="material_id.currency_id")

    system_brand_id = fields.Many2one('product.brand', string='Brand',related="group_id.brand_id")
    system_group_id = fields.Many2one('product.group', string='System Group',related="group_id.group_id")
    product_pricing_group = fields.Many2one(string='Pricing',related="group_id.product_pricing_group")

class MaterialLineData(models.Model):
    _name = "material.line.data"
    _description = "data inside the group material lines"


    material_sheet_id = fields.Many2one("material.sheet.line", string="Groups", ondelete='cascade')
    company_id = fields.Many2one(related='material_sheet_id.company_id', string='Company', store=True, readonly=True,
                                 index=True)
    product_id = fields.Many2one(
        'product.product', string='Product', required=True,
        domain="[('product_brand', '=', cs_brand),('product_group', '=', cs_group),'|', ('company_id', '=', False), ('company_id', '=', company_id)]",
        change_default=True, ondelete='restrict', check_company=True)  # Unrequired company
    product_template_id = fields.Many2one(
        'product.template', string='Product Template',
        related="product_id.product_tmpl_id")


    cs_brand = fields.Many2one("product.brand", string="CS Brand",related="material_sheet_id.system_brand_id",store=1)
    cs_group = fields.Many2one("product.group", string="CS Group",related="material_sheet_id.system_group_id")
    product_pricing_group = fields.Many2one(string='Pricing Group',related="material_sheet_id.product_pricing_group")
    product_pricing = fields.Many2one('product.pricing.settings',string='Product Pricing', compute="_compute_product_pricing")
    cs_model = fields.Char("CS Model", related='product_id.part_number')
    cs_description = fields.Text("CS Description",required=True)
    cs_qty = fields.Integer("CS Qty", default=0)
    cs_unit = fields.Many2one("uom.uom", string="CS Unit", related='product_id.uom_id')

    @api.depends('product_id')
    def _compute_product_pricing(self):
        for rec in self:
            product_pricing = self.env['product.pricing.settings'].search([('product_id', '=', rec.product_id.id)],
                                                                              limit=1)
            rec.product_pricing = product_pricing.id

    @api.onchange('product_pricing')
    def _get_product_vals(self):
        self.write({
            'unit_price': self.product_pricing.unit_price,
            'discount': str(self.product_pricing.discount*100),
            'currency_id': self.product_pricing.currency_id.id,
        })

    @api.onchange("cs_brand")
    def _default_brand(self):
        for rec in self:
            if rec.cs_brand:
                rec.quote_brand = rec.cs_brand.name

    quote_brand = fields.Char("Quote Brand")

    @api.onchange("cs_model")
    def _default_model(self):
        for rec in self:
            if rec.cs_model:
                rec.quote_model = rec.cs_model

    quote_model = fields.Char("Quote Model")

    @api.onchange("cs_description")
    def _default_description(self):
        for rec in self:
            if rec.cs_description:
                rec.quote_description = rec.cs_description

    quote_description = fields.Text("Quote Description")

    @api.onchange("cs_qty")
    def _default_qty(self):
        for rec in self:
            if rec.cs_qty:
                rec.quote_qty = rec.cs_qty

    quote_qty = fields.Integer("Quote Qty", default=0)

    @api.onchange("cs_unit")
    def _default_unit(self):
        for rec in self:
            if rec.cs_unit:
                rec.quote_unit = rec.cs_unit.id

    quote_unit = fields.Many2one("uom.uom", string="Quote Unit")
    ###########################################
    remarks = fields.Char("Remarks")
    discount = fields.Char("Discount")

    @api.onchange("discount")
    def onchange_discount(self):
        for rec in self:
            try:
                rec.discount = f"{float(rec.discount)}%"
            except  Exception:
                raise UserError(_("Enter discount as float number"))

    stock_qty = fields.Float("Stock QTY", related="product_id.qty_available", readonly=True, store=True)  # first manually
    forcasted_qty = fields.Float("Forecasted QTY", related="product_id.virtual_available", readonly=True, store=True)  # first manually

    def _default_currency(self):
        return self.company_id.currency_id.id

    currency_id = fields.Many2one('res.currency',
                                  string='Currency', readonly=False)
    currency_rate = fields.Float("Currency Exchange", compute="_exchange_rate", store=True, readonly=True,
                                 digits=(12, 12))

    @api.depends("currency_id")
    def _exchange_rate(self):
        for rec in self:
            try:
                base_currency = rec.material_sheet_id.material_id.cost_id.currency_id
                currency_company_id = self.company_id.currency_id
                if base_currency and rec.currency_id:
                    if base_currency.id == rec.currency_id.id:
                        rec.currency_rate = 1
                    else:
                        if base_currency.id == currency_company_id.id:
                            rate_id = rec.env["res.currency.rate"].search([("currency_id", "=", rec.currency_id.id),
                                                                           ("company_id", "=", self.company_id.id),
                                                                           ("name", "<=",
                                                                            rec.material_sheet_id.material_id.cost_id.issue_date)],
                                                                          limit=1, order='name desc')
                            rec.currency_rate = rate_id.rate
                        else:
                            base_rate_id = rec.env["res.currency.rate"].search([("currency_id", "=", base_currency.id),
                                                                                ("company_id", "=", self.company_id.id),
                                                                                ("name", "<=",
                                                                                 rec.material_sheet_id.material_id.cost_id.issue_date)],
                                                                               limit=1, order='name desc')
                            base_rate = base_rate_id.rate
                            rate_id = rec.env["res.currency.rate"].search([("currency_id", "=", rec.currency_id.id),
                                                                           ("company_id", "=", self.company_id.id),
                                                                           ("name", "<=",
                                                                            rec.material_sheet_id.material_id.cost_id.issue_date)],
                                                                           limit=1, order='name desc')
                            rate = rate_id.rate
                            rec.currency_rate = rate / base_rate
            except Exception as e:
                raise UserError(_(str(e)))

    unit_price = fields.Float("Unit List/Unit Net Price")
    base_unit_price = fields.Float("Unit List /Unit Net price in CS Base Currency", compute="_price_exchange_rate",
                                   store=True, readonly=True)

    @api.depends("unit_price", "currency_rate", "discount")
    def _price_exchange_rate(self):
        for rec in self:
            try:
                if rec.unit_price and rec.currency_rate:
                    discount = float(rec.discount.replace("%", ""))
                    rec.base_unit_price = (rec.unit_price / rec.currency_rate) * (1 - (discount / 100))
            except Exception as e:
                raise UserError(_(str(e)))

    # calculate
    total_price = fields.Float("Total Net Price", compute="_compute_total", inverse="_inverse_update_summary",
                               store=True, readonly=True, default=0)

    def _inverse_update_summary(self):
        self.material_sheet_id.material_id.update_summary_lines()

    @api.depends("base_unit_price", "cs_qty")
    def _compute_total(self):
        for rec in self:
            if rec.base_unit_price and rec.cs_qty:
                rec.total_price = rec.base_unit_price * rec.cs_qty
        self.material_sheet_id.material_id.update_summary_lines()

    total_custom_price = fields.Float("T.Custom Cost", compute="_compute_total_custom",
                                      store=True, readonly=True, default=0)

    @api.depends("total_price", "material_sheet_id","material_sheet_id.group_id.custom")
    def _compute_total_custom(self):
        for rec in self:
            if rec.total_price and rec.material_sheet_id:
                custom = (rec.material_sheet_id.group_id.custom)
                rec.total_custom_price = rec.total_price * custom
        self.material_sheet_id.material_id.update_summary_lines()

    total_shipping_cost = fields.Float("T.Shipping Cost", compute="_compute_total_shipping",
                                       store=True, readonly=True, default=0)

    @api.depends("total_price", "material_sheet_id","material_sheet_id.group_id.shipping")
    def _compute_total_shipping(self):
        for rec in self:
            if rec.total_price and rec.material_sheet_id:
                shipping = (rec.material_sheet_id.group_id.shipping)
                rec.total_shipping_cost = rec.total_price * shipping
        self.material_sheet_id.material_id.update_summary_lines()

    total_risk_cost = fields.Float("T.Risk Cost", compute="_compute_total_risk",
                                   store=True, readonly=True, default=0)

    @api.depends("total_price", "material_sheet_id","material_sheet_id.group_id.material_risk")
    def _compute_total_risk(self):
        for rec in self:
            if rec.total_price and rec.material_sheet_id:
                risk = (rec.material_sheet_id.group_id.material_risk)
                rec.total_risk_cost = rec.total_price * risk
        self.material_sheet_id.material_id.update_summary_lines()

    total_landed_cost = fields.Float("U.Landed Cost", compute="_compute_land_cost",
                                     store=True, readonly=True, default=0)

    @api.depends("base_unit_price","material_sheet_id.group_id.custom","material_sheet_id.group_id.shipping")
    def _compute_land_cost(self):
        for rec in self:
            if rec.base_unit_price and rec.material_sheet_id:
                custom = (rec.material_sheet_id.group_id.custom)
                shipping = (rec.material_sheet_id.group_id.shipping)
                rec.total_landed_cost = rec.base_unit_price * (1 + custom + shipping)
        self.material_sheet_id.material_id.update_summary_lines()

    total_landed_price = fields.Float("T.Landed Price", compute="_compute_land_price",inverse="_inverse_update_summary",
                                      store=True, readonly=True, default=0)

    @api.depends("cs_qty", "total_landed_cost")
    def _compute_land_price(self):
        for rec in self:
            if rec.cs_qty and rec.total_landed_cost:
                rec.total_landed_price = rec.cs_qty * rec.total_landed_cost
        self.material_sheet_id.material_id.update_summary_lines()
    unit_oh_cost = fields.Float("U.Cost/OH", compute="_compute_unit_oh",
                                store=True, readonly=True, default=0)

    @api.depends("total_landed_cost", "material_sheet_id.group_id.material_risk","material_sheet_id.group_id.oh")
    def _compute_unit_oh(self):
        for rec in self:
            oh = (rec.material_sheet_id.group_id.oh)
            risk = (rec.material_sheet_id.group_id.material_risk)
            rec.unit_oh_cost = rec.total_landed_cost * (1 + oh + risk)
        self.material_sheet_id.material_id.update_summary_lines()

    total_oh_cost = fields.Float("T.Cost/OH", compute="_compute_total_oh", inverse="_inverse_update_summary",
                                 store=True, readonly=True, default=0)

    @api.depends("cs_qty", "unit_oh_cost")
    def _compute_total_oh(self):
        for rec in self:
            if rec.cs_qty and rec.unit_oh_cost:
                rec.total_oh_cost = rec.cs_qty * rec.unit_oh_cost
        self.material_sheet_id.material_id.update_summary_lines()

    unit_selling_price = fields.Float("U.Selling Price", compute="_compute_unit_selling",

                                      store=True, readonly=True, default=0)

    def get_selling_price(self):
        margin = self.material_sheet_id.group_id.margin
        result = self.unit_oh_cost / (1 - margin)
        # return math.ceil(result / 10.0) * 10 # round to nearest 10
        return math.ceil(result)


    @api.depends("material_sheet_id.group_id.margin","unit_oh_cost")
    def _compute_unit_selling(self):
        for rec in self:
            rec.unit_selling_price = rec.get_selling_price()
            rec._inverse_unit_selling_price()
        self.material_sheet_id.material_id.update_summary_lines()

    total_selling_price = fields.Float("T.Selling Price", compute="_compute_total_selling",
                                       store=True, readonly=True, default=0)

    @api.depends("unit_selling_price", "cs_qty")
    def _compute_total_selling(self):
        for rec in self:
            rec.total_selling_price = rec.unit_selling_price * rec.cs_qty
        self.material_sheet_id.material_id.update_summary_lines()

    final_unit = fields.Float("Final U.P")  # default like U. Selling Price

    @api.onchange("final_unit")
    def _validation_on_final_unit(self):
        if self.final_unit and self.final_unit < self.unit_selling_price:
            raise ValidationError("'Final U.P' Must Be Greater Than 'U. Selling Price'")

    @api.onchange("unit_selling_price")
    def _inverse_unit_selling_price(self):
        for rec in self:
            rec.final_unit = rec.get_selling_price()

    final_total = fields.Float("Final T.P", compute="_compute_final_total",inverse="_inverse_update_summary",
                               store=True, readonly=True, default=0)

    @api.depends("final_unit", "cs_qty")
    def _compute_final_total(self):
        for rec in self:
            if rec.final_unit and rec.cs_qty:
                rec.final_total = rec.final_unit * rec.cs_qty
        self.material_sheet_id.material_id.update_summary_lines()