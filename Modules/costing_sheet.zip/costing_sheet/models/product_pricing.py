# -*- coding: utf-8 -*-
#################################################################################
# Author      : Acespritech Solutions Pvt. Ltd. (<www.acespritech.com>)
# Copyright(c): 2012-Present Acespritech Solutions Pvt. Ltd.
# All Rights Reserved.
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#################################################################################

from odoo import models, fields, api,_
from odoo.exceptions import ValidationError
import math

class ProductPricingSettings(models.Model):
    _name = 'product.pricing.settings'
    _description = "Product Pricing Settings"


    # name = fields.Char('Reference', copy=False, readonly=True, default=lambda x: _('New'))

    product_id = fields.Many2one('product.product', string='Product', required=1)
    unit_price = fields.Float(string='Unit Price')
    currency_id = fields.Many2one('res.currency', string='Currency', required=1)
    discount = fields.Float(string='Discount %')
    remarks = fields.Char(string='Remarks')
    # 6. Selling Price. Calculated as ((Unit Price * (1 + Customs %) * (1 + Shipping %)) * (1 + OH % + Material Risk %)) / (1-Margin %)
    # 7. Selling Price with Installation, calculated as (((Unit Price * (1 + Customs %) * (1 + Shipping %)) * (1 + OH % + Material Risk %)) / (1-Margin %)) * (1+Installation %).
    selling_price = fields.Float(string='Selling Price',compute="compute_selling_price")
    selling_price_installation = fields.Float(string='Selling Price With Installation',compute="compute_selling_price")

    # product_pricing_group = fields.Many2one('product.group.settings', string='Product Pricing Settings',compute="_get_product_pricing_group")
    product_pricing_group = fields.Many2one('product.group.settings', string='Product Pricing Settings',compute="compute_selling_price")

    # @api.depends('product_id')
    # def _get_product_pricing_group(self):
    #     for record in self:
    #         product_pricing_group = self.env['product.group.settings'].search(
    #                 [('brand_id', '=', record.product_id.product_brand.id),
    #                  ('group_id', '=', record.product_id.product_group.id)], limit=1)
    #         record.product_pricing_group = product_pricing_group

    @api.onchange('product_id')
    def get_product_lst_price(self):
        for record in self:
            record.unit_price = record.product_id.lst_price

    # 'product_pricing_group.customs_val',
     # 'product_pricing_group.shipping_val',
     # 'product_pricing_group.oh_val',
     # 'product_pricing_group.material_risk_val',
     # 'product_pricing_group.margin_val',
     # 'product_pricing_group.installation_val',
    @api.depends('discount','unit_price', 'product_id', 'product_pricing_group')
    def compute_selling_price(self):
        for rec in self:
            product_pricing_group = self.env['product.group.settings'].search(
                    [('brand_id', '=', rec.product_id.product_brand.id),
                     ('group_id', '=', rec.product_id.product_group.id)], limit=1)
            rec.product_pricing_group = product_pricing_group

            unit_price_after_discount = rec.unit_price - (rec.discount * rec.unit_price)
            rec.selling_price = math.ceil(unit_price_after_discount)
            rec.selling_price_installation = math.ceil(unit_price_after_discount)
            if rec.product_id.product_group and rec.product_id.product_brand:
                if rec.product_pricing_group:
                    selling_price = ((unit_price_after_discount * (1 + rec.product_pricing_group.customs_val) * (1 + rec.product_pricing_group.shipping_val)) * (1 + rec.product_pricing_group.oh_val + rec.product_pricing_group.material_risk_val)) / (1-rec.product_pricing_group.margin_val) if not 1-rec.product_pricing_group.margin_val == 0 else 0
                    rec.selling_price = math.ceil(selling_price)

                    selling_price_installation = (((unit_price_after_discount * (1 + rec.product_pricing_group.customs_val) * (1 + rec.product_pricing_group.shipping_val)) * (1 + rec.product_pricing_group.oh_val + rec.product_pricing_group.material_risk_val)) / (1-rec.product_pricing_group.margin_val)) * (1+rec.product_pricing_group.installation_val) if not 1-rec.product_pricing_group.margin_val == 0 else 0
                    rec.selling_price_installation = math.ceil(selling_price_installation)

    @api.onchange('product_id')
    def onchange_product_id(self):
        product_exist = self.env['product.pricing.settings'].search([('product_id','=',self.product_id.id),('id','!=',False),('id','!=',self._origin.id)])
        if product_exist:
            raise ValidationError(_('This Product is already has a pricing settings.'))

    # @api.model
    # def create(self, vals):
    #     if not vals.get('name') or vals['name'] == _('New'):
    #         vals['name'] = self.env['ir.sequence'].next_by_code('product.pricing.settings') or _('New')
    #     return super(ProductPricingSettings, self).create(vals)
