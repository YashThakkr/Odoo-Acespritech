# -*- coding: utf-8 -*-
#################################################################################
# Author      : Acespritech Solutions Pvt. Ltd. (<www.acespritech.com>)
# Copyright(c): 2012-Present Acespritech Solutions Pvt. Ltd.
# All Rights Reserved.
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#################################################################################

from odoo import models, fields, api


class Purchase(models.Model):
    _inherit = 'purchase.order.line'

    price_with_installation = fields.Boolean(string='Price With Installation')

    def get_unit_calculated_price(self):
        product_price_group = self.env['product.pricing.settings'].search([('product_id', '=', self.product_id.id)],
                                                                          limit=1)
        calculated_price_unit = self.product_id.lst_price
        if product_price_group:
            price_group_currency = product_price_group.currency_id
            line_currency = self.env['res.currency'].browse(self.currency_id.id)
            calculated_price_unit = price_group_currency.compute(product_price_group.selling_price, line_currency)
            if self.price_with_installation:
                calculated_price_unit = price_group_currency.compute(product_price_group.selling_price_installation,
                                                                     line_currency)
        return calculated_price_unit

    @api.onchange('product_id','price_with_installation')
    def onchange_product_id(self):
        res = super(Purchase, self).onchange_product_id()

        self.price_unit = self.get_unit_calculated_price()

        return res

    @api.onchange('product_qty', 'product_uom')
    def _onchange_quantity(self):
        # res = super(Purchase, self)._onchange_quantity()
        self.price_unit = self.get_unit_calculated_price()

        # return res