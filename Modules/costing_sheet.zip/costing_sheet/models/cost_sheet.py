import math
from datetime import datetime, timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class CostSheet(models.Model):
    _name = "cost.sheet"
    _description = "costing sheet before quotation"

    state = fields.Selection([
        ('draft', 'Draft'),
        ('approve', 'Wait For Approved'),
        ('done', 'Done'),
        ('cancel', 'Cancelled'),
    ], string='Status', readonly=True, copy=False, index=True, default='draft')

    approved = fields.Boolean("Approved", default=False)
    approved_date = fields.Datetime()

    def get_lead_system_data(self):
        for each in self:
            # self.env['install.sheet.line'].search([('system_id','in',self.system_ids.ids)]).unlink()
            systems = self.env['system.system'].browse(each.system_ids.ids)
            systems.update({'cost_id': False})
            self.sudo().env['install.sheet.line'].search([('system_id','in',systems.ids)]).update({'installation_id': False})
            if each.lead_id and each.lead_id.system_info_ids:
                for line in each.lead_id.system_info_ids:
                    self.env['system.system'].create({'cost_id':each._origin.id,
                                                      'name': line.interested_product,
                                                      'system_info_id': line.system_info_id.id})

    @api.onchange("lead_id")
    def _get_qualified_lead(self):
        qualifier_stage = self.env["crm.stage"].search([("name", "=", "Qualified")])
        if qualifier_stage:
            stage_id = qualifier_stage.id
            qualifier_lead = self.env["crm.lead"].search([("stage_id", "=", stage_id)])
            if qualifier_lead:
                leads = [ids.id for ids in qualifier_lead]
                res = {'domain': {'lead_id': [('id', 'in', leads)]}}
                return res
        return {'domain': {'lead_id': [("id", "in", [])]}}

    lead_id = fields.Many2one("crm.lead", "Lead")
    project_name = fields.Char(related="lead_id.project_name")
    project_type = fields.Many2one(related="lead_id.project_type")
    type = fields.Selection(related="project_type.type")
    rfi_number = fields.Char("RFI Contact Number", related="lead_id.rfi_number", readonly=True)
    department_id = fields.Many2one("hr.department", string='Department',
                                    domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]")

    customer_id = fields.Many2one(related="lead_id.partner_id")

    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,
                                 default=lambda self: self.env.company)
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id.id,
                                  string='Currency', readonly=False)

    name = fields.Char('Costing Number', index=True, required=True, readonly=True, copy=False, default="New")
    
    def name_get(self):
        result = []
        for record in self:
            result.append((record.id, record.name))
        return result

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", 'New') == "New":
                vals['name'] = self.env['ir.sequence'].next_by_code('seq.cost.sheet') or 'New'
        cost = super(CostSheet, self.with_context(default_currency_id=vals.get("currency_id",False))).create(vals_list)
        # if vals.get('lead_id'):
        # cost.get_lead_system_data()
        return cost

    def write(self, values):
        # add logic here
        # self.update_material()
        result = super(CostSheet, self).write(values)
        # if 'lead_id' in values and values['lead_id']:
        #     self.get_lead_system_data()
        return result

    revision = fields.Char("Revision", readonly=True, default="1")
    issue_date = fields.Date("Issue Date", default=datetime.now())

    # page 1
    @api.model
    def _get_validity(self):
        quotation_validity = self.env['ir.config_parameter'].sudo().get_param(
            'sale.use_quotation_validity_days') or False
        if quotation_validity:
            validate = self.env.company.quotation_validity_days
            return datetime.now() + timedelta(days=validate)

    validity_date = fields.Date("Validity Date", default=_get_validity)
    completion_date = fields.Date("Completion Date", readonly=True)  # when send the approval
    approved_by = fields.Many2one("res.users", readonly=True)  # when the user approved
    discount = fields.Char("Discount")

    @api.onchange("discount")
    def _onchange_discount(self):
        for rec in self:
            try:
                if rec.discount:
                    rec.discount = f"{rec.discount}%"
            except Exception:
                UserError(_("You should add discount number not string"))

    discount_approved_by = fields.Many2one("res.users")

    notes = fields.Text("Terms and conditions")
    revision_reason = fields.Text(string="Reason of Revision")  # when the revision became 2

    @api.onchange('project_type')
    def _onchange_project_type(self):
        if self.project_type.note:
            self.notes = self.project_type.note
        else:
            self.notes = False

    # states button
    def action_cancel(self):
        return {
            'name': _('Cancel Costing Sheet'),
            'view_mode': 'form',
            'res_model': 'cost.sheet.cancel',
            'view_id': self.env.ref('costing_sheet.cost_sheet_cancel_view_form').id,
            'type': 'ir.actions.act_window',
            'context': {'default_cost_id': self.id},
            'target': 'new'
        }

    def action_draft(self):
        sheets = self.filtered(lambda s: s.state in ['cancel'])
        return sheets.write({'state': 'draft', 'approved': False})

    def action_to_approve(self):
        return self.write({'state': 'approve', "completion_date": datetime.now()})

    def button_approve(self):
        self = self.filtered(lambda order: order._approval_allowed())
        self.write(
            {'state': 'done', 'approved_date': fields.Datetime.now(), "approved": True, "approved_by": self.env.uid})

    def _approval_allowed(self):
        """Returns whether the order qualifies to be approved by the current user"""
        self.ensure_one()
        return (self.user_has_groups('costing_sheet.cost_sheet_approve'))

    #########################################################################
    # revision
    cost_revision_id = fields.Many2one("cost.sheet")
    is_revision = fields.Boolean(default=False)
    rev_count = fields.Integer(compute="compute_rev_count", default=0)

    def compute_rev_count(self):
        for record in self:
            self.rev_count = record.env['cost.sheet'].search_count([('is_revision', '=', True),
                                                                    ('cost_revision_id', '=', self.id)])

    def get_revision(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Revision Cost',
            'view_mode': 'tree,form',
            'view_type': 'form',
            'res_model': 'cost.sheet',
            'domain': [('is_revision', '=', True), ('cost_revision_id', '=', self.id)],
        }
    #################################################
    # smart button for the quotation
    quote_count = fields.Integer(compute="compute_quote_count", default=0)

    def compute_quote_count(self):
        for record in self:
            self.quote_count = record.env['sale.order'].search_count([('cost_id', '=', self.id)])
    def get_quote(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Quotations',
            'view_mode': 'tree,form',
            'view_typuoe': 'form',
            'res_model': 'sale.order',
            'domain': [('cost_id', '=', self.id)],
        }

    ##################################################
    # update the material sheet
    def update_material(self):
        material = self.env["material.sheet"].search([("cost_id", "=", self.id)])
        if material:
            for system in self.system_ids:
                for group in system.group_ids:
                    custom = (group.custom / 100)
                    shipping = (group.shipping / 100)
                    oh = (group.oh / 100)
                    risk = (group.material_risk / 100)
                    margin = (group.margin / 100)
                    sheet = self.env["material.sheet.line"].search([("material_id", "=", material.id),
                                                                    ("system_id", "=", system.id),
                                                                    ("group_id", "=", group.id)])
                    if sheet:
                        for line in sheet.line_ids:
                            total_landed_cost = line.base_unit_price * (1 + custom + shipping)
                            unit_oh_cost = total_landed_cost * (1 + oh + risk)
                            unit_selling_price = math.ceil(unit_oh_cost / (1 - margin))
                            line.update({"total_custom_price": line.total_price * custom,
                                         "total_shipping_cost": line.total_price * shipping,
                                         "total_risk_cost": line.total_price * risk,
                                         "total_landed_cost": total_landed_cost, "unit_oh_cost": unit_oh_cost,
                                         "unit_selling_price": unit_selling_price})

    
    def update_summary(self):
        summary = self.env["cost.sheet.summary"].search([("cost_id", "=", self.id),("name", "!=", "Total")])
        if summary:
            net_cost,  land_cost, overhead, land_oh_cost, selling_price, discount, net_price, net_profit = 0, 0, 0, 0, 0, 0, 0, 0
            for data in summary:
                net_cost += data.net_cost
                land_cost += data.land_cost
                overhead += data.overhead
                land_oh_cost += data.land_oh_cost
                selling_price += data.selling_price
                discount += data.discount
                net_price += data.net_price
                net_profit += data.net_profit
            fetch_summary = self.env["cost.sheet.summary"].search([("cost_id", "=", self.id), ("name", "=", "Total")])
            if not fetch_summary:
                self.env["cost.sheet.summary"].create({"cost_id": self.id, "name": "Total", "net_cost": net_cost,
                                                       "land_cost": land_cost, "overhead": overhead,
                                                       "land_oh_cost": land_oh_cost, "selling_price": selling_price,
                                                       "discount": discount, "net_price": net_price,
                                                       'seq':3,
                                                       "net_profit": net_profit})
    
            else:
                fetch_summary.write({ "net_cost": net_cost,
                                                       "land_cost": land_cost, "overhead": overhead,
                                                       "land_oh_cost": land_oh_cost, "selling_price": selling_price,
                                                       "discount": discount, "net_price": net_price,
                                                       "net_profit": net_profit})


    #########################################################
    # material and installation smart button
    material_count = fields.Integer(compute="_compute_material_num", default=0)

    def _compute_material_num(self):
        for record in self:
            self.material_count = record.env['material.sheet'].search_count([('cost_id', '=', self.id)])

    def get_material(self):
        self.ensure_one()
        material = self.env["material.sheet"].search([("cost_id", "=", self.id)])
        return {
            'type': 'ir.actions.act_window',
            'name': 'Material Sheet',
            'view_mode': 'form',
            'view_type': 'form',
            'res_model': 'material.sheet',
            'res_id': material.id,
        }

    install_count = fields.Integer(compute="_compute_install_num", default=0)

    def _compute_install_num(self):
        for record in self:
            self.install_count = record.env['install.sheet'].search_count([('cost_id', '=', self.id)])

    def get_installation(self):
        self.ensure_one()
        systems = []
        if self.install_count == 0:
            for val in self.system_ids:
                systems.append((0, 0, {'system_id': val.id}))
            return {
                'type': 'ir.actions.act_window',
                'name': 'Installation Sheet',
                'view_mode': 'form',
                'view_type': 'form',
                'res_model': 'install.sheet',
                'domain': [('cost_id', '=', self.id)],
                'context': {'default_cost_id': self.id, "default_lead_id": self.lead_id.id,
                            "default_project_name": self.project_name, "default_project_type": self.project_type.id,
                            "default_sheet_rev": self.revision, "default_line_ids": systems}
            }
        install = self.env["install.sheet"].search([("cost_id", "=", self.id)])
        return {
            'type': 'ir.actions.act_window',
            'name': 'Installation Sheet',
            'view_mode': 'form',
            'view_type': 'form',
            'res_model': 'install.sheet',
            'res_id': install.id,
        }

    #############################################
    # pages
    system_ids = fields.One2many("system.system", "cost_id")
    summary_ids = fields.One2many("cost.sheet.summary", "cost_id")
    ####################################################


class CostSheetSummary(models.Model):
    _name = "cost.sheet.summary"
    _description = "summary for the cost sheet"
    _order = "seq"
    
    cost_id = fields.Many2one("cost.sheet", ondelete='cascade', readonly=True, string='Summary Cost')
    name = fields.Char(string="", readonly=True)
    net_cost = fields.Float("Net Cost", readonly=True)
    land_cost = fields.Float("Landed Cost  (including shipping & Custom)", readonly=True)
    seq = fields.Integer("Sequence")
    overhead = fields.Float("Overhead", readonly=True)
    land_oh_cost = fields.Float("Landed Cost & OH", readonly=True)
    selling_price = fields.Float("Selling Price", readonly=True)
    discount = fields.Float("Discount", readonly=True)
    net_price = fields.Float("Net Selling Price", readonly=True)
    net_profit = fields.Float("Margin/Net Profit", readonly=True)
    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,
                                 default=lambda self: self.env.company)
