from odoo import models, fields


class Lead(models.Model):
    _inherit = "crm.lead"

    stage_name = fields.Char(related="stage_id.name")
    sheet_count = fields.Integer(compute="compute_sheet_count", default=0)

    def compute_sheet_count(self):
        for record in self:
            self.sheet_count = record.env['cost.sheet'].search_count([('lead_id', '=', self.id)])

    def get_sheet(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Cost Sheet',
            'view_mode': 'tree,form',
            'view_type': 'form',
            'res_model': 'cost.sheet',
            'domain': [('lead_id', '=', self.id)],
            'context': {'default_lead_id': self.id, "default_project_name": self.project_name,
                        "default_project_type": self.project_type.id,
                        "default_customer_id": self.partner_id.id}
        }
