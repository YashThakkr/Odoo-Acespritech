from odoo import api ,models, fields

class PO(models.Model):
    _inherit = "purchase.order"

    material_sheet_id = fields.Many2one("material.sheet")

class SaleOrder(models.Model):
    _inherit = "sale.order"

    cost_id = fields.Many2one("cost.sheet", string='Cost ID')

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    price_with_installation = fields.Boolean(string='Price With Installation')
    cost_id = fields.Many2one(related="order_id.cost_id")
    is_from_cost_sheet = fields.Boolean(string='Is From Cost Sheet',compute="get_is_from_cost_sheet")

    def get_is_from_cost_sheet(self):
        for line in self:
            line.is_from_cost_sheet = False
            if line.order_id.cost_id:
                line.is_from_cost_sheet = True

    def get_unit_calculated_price(self):
        product_price_group = self.env['product.pricing.settings'].search([('product_id', '=', self.product_id.id)],limit=1)

        calculated_price_unit = self.product_id.lst_price
        if product_price_group:
            price_group_currency = product_price_group.currency_id
            line_currency = self.env['res.currency'].browse(self.currency_id.id)
            calculated_price_unit = price_group_currency.compute(product_price_group.selling_price, line_currency)
            if self.price_with_installation:
                calculated_price_unit = price_group_currency.compute(product_price_group.selling_price_installation, line_currency)

        return calculated_price_unit


    @api.onchange('product_id', 'product_uom', 'product_uom_qty', 'tax_id','price_with_installation')
    def _onchange_discount(self):
        res = super(SaleOrderLine, self)._onchange_discount()

        for line in self:
            if not line.order_id.cost_id:
                line.price_unit = line.get_unit_calculated_price()

        return res

    @api.onchange('product_uom', 'product_uom_qty','price_with_installation')
    def product_uom_change(self):
        # res = super(SaleOrderLine, self).product_uom_change()
        if not self.order_id.cost_id:
            self.price_unit = self.get_unit_calculated_price()
        # return res