from odoo import models, fields,api
import math


class System(models.Model):
    _name = "system.system"
    _description = "system data"

    name = fields.Char(string="System Code")#, required=True
    cost_id = fields.Many2one("cost.sheet", ondelete='cascade', string='System Cost')
    group_ids = fields.One2many("system.group", "system_id", string="Groups")
    section_ids = fields.One2many('system.section','section_id',string="Sections")

    installation_group_ids = fields.One2many("system.group", "system_id", string="Groups")
    installation_section_ids = fields.One2many('system.section', 'installation_section_id', string="Sections")

    oh = fields.Float("Installation OH %")
    margin = fields.Float("Installation Margin%:")
    risk = fields.Float("Installation Risk %")
    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,
                                 default=lambda self: self.env.company)
    display_type = fields.Selection(
        selection=[
            ('line_section', "Section"),
            ('line_note', "Note"),
        ],
        default=False)
    sequence = fields.Integer(string='Sequence', default=10)
    system_info_id = fields.Many2one('crm.system.information', string='System Name', required=True)

    line_custom = fields.Float(string="Customs")
    line_shipping = fields.Float(string="Shipping")
    line_oh = fields.Float(string="OH")
    line_margin = fields.Float(string="Margin")
    line_material_risk = fields.Float(string="Material Risk")
    line_installation = fields.Float(string="Installation")
    line_ceiling = fields.Float(string="Ceiling")

    overview_ids = fields.One2many('system.overview', 'system_id', string="Overview")
    overview_com = fields.Text(string='Overview', store=True, compute='_compute_overview_ids')
    
    installation_ids = fields.One2many('system.overview', 'installation_system_id', string="Installation")
    installation_com = fields.Text(string='Overview', store=True, compute='_compute_installation_ids')

    @api.model_create_multi
    @api.returns('self', lambda value: value.id)
    def create(self, vals_list):
        systems = super(System, self).create(vals_list)
        # for rec in systems:
        #     installation = self.env["install.sheet"].search([('cost_id', '=', rec.cost_id.id)],limit=1)
        #     material_vals = []
        #     for mat in rec.cost_id.project_type.default_install_line_data:
        #         material_vals.append((0,0,{'company_id':mat.company_id.id,'product_id':mat.product_id.id,
        #                                     'cs_brand':mat.cs_brand.id,'model':mat.model,'description':mat.description,
        #                                     'qty':mat.qty,'unit':mat.unit.id,'currency_id':mat.currency_id.id,'unit_price':mat.unit_price,}))
        #
        #     if not installation:
        #         installation = self.env["install.sheet"].create([{'cost_id':rec.cost_id.id}])
        #     installation.line_ids = [(0,0,{'system_id':rec.id,'install_line_data':material_vals})]
        return systems

    @api.onchange('system_info_id')
    def update_config_parameters(self):
        for line in self:
            line.line_custom = line.system_info_id.line_custom
            line.line_shipping = line.system_info_id.line_shipping
            line.line_oh = line.system_info_id.line_oh
            line.line_margin = line.system_info_id.line_margin
            line.line_material_risk = line.system_info_id.line_material_risk
            line.line_installation = line.system_info_id.line_installation
            line.line_ceiling = line.system_info_id.line_ceiling
            line.margin = line.system_info_id.installation_margin
            line.risk = line.system_info_id.installation_risk
            line.oh = line.system_info_id.installation_oh

    # def name_get(self):
    #     res = []
    #     for sys in self:
    #         name = sys.system_info_id.name
    #         if sys.system_info_id:
    #             name = '['+sys.system_info_id.code+'] '+name
    #         res.append((sys.id, name))
    #     return res

    @api.onchange('system_info_id')
    def onchange_system_info(self):
        for line in self:
            name = ''
            if line.system_info_id:
                name = line.system_info_id.code
            line.name = name

    def view_get_record(self):
        action = self.env.ref('costing_sheet.action_system_system').read()[0]
        action['domain'] = [('id','=',self.id)]
        action['res_id'] = self.id
        return action

    @api.depends('installation_section_ids', 'installation_section_ids.group_ids')
    def _compute_installation_ids(self):
        for system in self:
            system.installation_ids.unlink()
            overview_values = []
            for section in system.installation_section_ids:
                overview_values.append((0, 0, {
                    'name': section.name,
                    'system_id': section.section_id,
                    'currency_id': self.env.company.currency_id.id,
                    'display_type': 'line_section'
                }))
                if section.group_ids:
                    for grp in section.group_ids:
                        overview_values.append((0, 0, {
                            'name': grp.name,
                            'system_id': grp.system_id.id,
                            'display_type': grp.display_type,
                            'product_id': grp.product_id.id,
                            'brand_id': grp.brand_id.id,
                            'group_id': grp.group_id.id,
                            'quantity': grp.quantity,
                            'unit_price': grp.unit_price,
                            'total_price': grp.total_price,
                            'currency_id': grp.currency_id.id,
                            'unit_list_price': grp.unit_list_price,
                            'list_price_in_sar': grp.list_price_in_sar,
                            'total_list_price': grp.total_list_price,
                            'unit_landed_cost': grp.unit_landed_cost,
                            'total_landed_cost': grp.total_landed_cost,
                            'unit_cost': grp.unit_cost,
                            'total_cost': grp.total_cost,
                            'unit_selling_price': grp.unit_selling_price,
                            'total_selling_price': grp.total_selling_price,
                        }))
            system.update({
                'installation_ids': overview_values,
            })
            system.installation_com = system.id

    @api.depends('section_ids', 'section_ids.group_ids')
    def _compute_overview_ids(self):
        for system in self:
            system.overview_ids.unlink()
            overview_values = []
            for section in system.section_ids:
                overview_values.append((0, 0, {
                    'name':  section.name,
                    'system_id': section.section_id,
                    'currency_id': self.env.company.currency_id.id,
                    'display_type': 'line_section'
                }))
                if section.group_ids:
                    for grp in section.group_ids:
                        overview_values.append((0, 0, {
                            'name': grp.name,
                            'system_id': grp.system_id.id,
                            'display_type': grp.display_type,
                            'product_id': grp.product_id.id,
                            'brand_id': grp.brand_id.id,
                            'group_id': grp.group_id.id,
                            'quantity': grp.quantity,
                            'unit_price': grp.unit_price,
                            'total_price': grp.total_price,
                            'currency_id': grp.currency_id.id,
                            'unit_list_price': grp.unit_list_price,
                            'list_price_in_sar': grp.list_price_in_sar,
                            'total_list_price': grp.total_list_price,
                            'unit_landed_cost': grp.unit_landed_cost,
                            'total_landed_cost': grp.total_landed_cost,
                            'unit_cost': grp.unit_cost,
                            'total_cost': grp.total_cost,
                            'unit_selling_price': grp.unit_selling_price,
                            'total_selling_price': grp.total_selling_price,
                        }))
            system.update({
                'overview_ids': overview_values,
            })

            system.overview_com = system.id

    total = fields.Monetary(string="Total sum", compute="update_total_prices")
    currency_id = fields.Many2one("res.currency", string="Currency")
    @api.depends('overview_ids')
    def update_total_prices(self):
        total_val = 0.0
        for record in self.overview_ids:
            total_val += record.total_price

        self.total = total_val


class Section(models.Model):
    _name = "system.section"
    _description = "section data"

    name = fields.Char(string="Description", required=True)
    display_type = fields.Selection(
        selection=[
            ('line_section', "Section"),
            ('line_note', "Note"),
        ],
        default=False)
    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,
                                 default=lambda self: self.env.company)
    section_id = fields.Many2one('system.system',string="System", ondelete='cascade')
    installation_section_id = fields.Many2one('system.system', string="System", ondelete='cascade')

    system_info_id = fields.Many2one('crm.system.information', string='System Name', related="section_id.system_info_id")
    system_installation_info_id = fields.Many2one('crm.system.information', string='System Name', related="installation_section_id.system_info_id")
    sequence = fields.Integer(string='Sequence', default=10)
    group_ids = fields.One2many("system.group", "section_system_id", string="Groups")
    currency_id = fields.Many2one("res.currency",string="Unit List Price Currency",required=True)
    # fetching data from system.system
    line_custom = fields.Float(string="Customs")
    line_shipping = fields.Float(string="Shipping")
    line_oh = fields.Float(string="OH")
    line_margin = fields.Float(string="Margin")
    line_material_risk = fields.Float(string="Material Risk")
    line_installation = fields.Float(string="Installation")
    line_ceiling = fields.Float(string="Ceiling")

    installation_oh = fields.Float(string="Installation OH %")
    installation_margin = fields.Float(string="Installation Margin %")
    installation_risk = fields.Float(string="Installation Material Risk %")

    @api.onchange('line_ceiling')
    def update_line_ceiling(self):
        ceiling = self.line_ceiling * 100
        margin = 1 - self.line_margin
        for record in self.group_ids:
            unit_cost = record.unit_cost / margin
            if not ceiling:
                record.unit_selling_price = math.ceil(unit_cost) * 0
            else:
                record.unit_selling_price = math.ceil(unit_cost / ceiling) * ceiling

    @api.onchange('name')
    def update_section_config_parameters(self):
        for line in self:
            if line.section_id:
                if line.display_type != 'line_section':
                    if not line.line_custom:
                        line.line_custom = line.system_info_id.line_custom
                    if not line.line_shipping:
                        line.line_shipping = line.system_info_id.line_shipping
                    if not line.line_oh:
                        line.line_oh = line.system_info_id.line_oh
                    if not line.line_margin:
                        line.line_margin = line.system_info_id.line_margin
                    if not line.line_material_risk:
                        line.line_material_risk = line.system_info_id.line_material_risk
                    if not line.line_installation:
                        line.line_installation = line.system_info_id.line_installation
                    if not line.line_ceiling:
                        line.line_ceiling = line.system_info_id.line_ceiling
                    if not line.installation_oh:
                        line.installation_oh = line.system_info_id.installation_oh
            elif line.installation_section_id:
                if line.display_type != 'line_section':
                        if not line.line_custom:
                            line.line_custom = line.system_installation_info_id.line_custom
                        if not line.line_shipping:
                            line.line_shipping = line.system_installation_info_id.line_shipping
                        if not line.line_oh:
                            line.line_oh = line.system_installation_info_id.line_oh
                        if not line.line_margin:
                            line.line_margin = line.system_installation_info_id.line_margin
                        if not line.line_material_risk:
                            line.line_material_risk = line.system_installation_info_id.line_material_risk
                        if not line.line_installation:
                            line.line_installation = line.system_installation_info_id.line_installation
                        if not line.line_ceiling:
                            line.line_ceiling = line.system_installation_info_id.line_ceiling
                        if not line.installation_oh:
                            line.installation_oh = line.system_installation_info_id.installation_oh

    def view_group_line(self):
        action = self.env.ref('costing_sheet.action_system_section').read()[0]
        action['domain'] = [('id','=',self.id)]
        action['res_id'] = self.id
        return action
        # return {
        #     'name': 'System Group Detail',
        #     'type': 'ir.actions.act_window',
        #     'res_model': 'system.section',
        #     'target': 'new',
        #     'view_mode': 'form',
        #     'res_id': self.id,
        # }


class Group(models.Model):
    _name = "system.group"
    _description = "group data"

    system_id = fields.Many2one("system.system", ondelete='cascade')
    section_system_id = fields.Many2one('system.section',ondelete='cascade')

    product_id = fields.Many2one('product.product', string='Product')
    brand_id = fields.Many2one('product.brand', string='Brand')
    group_id = fields.Many2one('product.group', string='Group')
    # below field is commented in view as functionality is not required
    product_pricing_group = fields.Many2one('product.group.settings',
                                            string='Pricing',
                                            compute="_get_product_pricing_group")

    name = fields.Char(string="Description", required=True)

    custom = fields.Float("Custom",compute="_get_product_pricing_vals")
    shipping = fields.Float("Shipping",compute="_get_product_pricing_vals")
    oh = fields.Float("OH",compute="_get_product_pricing_vals")
    margin = fields.Float("Margin",compute="_get_product_pricing_vals")
    ceiling = fields.Float("Ceiling", compute="_get_product_pricing_vals")
    material_risk = fields.Float("Material Risk",compute="_get_product_pricing_vals")
    installation = fields.Float("Installation",compute="_get_product_pricing_vals")

    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,
                                 default=lambda self: self.env.company)
    display_type = fields.Selection(
        selection=[
            ('line_section', "Section"),
            ('line_note', "Note"),
        ],
        default=False)
    sequence = fields.Integer(string='Sequence', default=10)

    quantity = fields.Integer(string="Qty",default=1)
    unit_price = fields.Float(string="Unit Price",compute="update_total_unit_price")
    total_price = fields.Float(string="Total Price",compute="update_total_unit_price")
    cost_currency_id = fields.Many2one("res.currency",string="Cost Currency",compute="fetch_cost_currency_id")
    currency_id = fields.Many2one("res.currency",string="Currency",required=True)
    converted_price = fields.Monetary(string='Price in New Currency',currency_field="currency_id",compute="convert_currency")
    unit_list_price = fields.Monetary(string="Unit List Price", currency_field='currency_id',required=True)
    discount = fields.Float(string="Discount")
    list_price_in_sar = fields.Monetary(string="Unit List Price in SAR",compute="update_list_prices", currency_field='cost_currency_id')
    total_list_price = fields.Float(string="Total List Price",compute="update_list_prices")
    unit_landed_cost = fields.Float(string="U. Landed Cost",compute="update_landed_costs_prices")
    total_landed_cost = fields.Float(string="T. Landed Cost",compute="update_landed_costs_prices")
    unit_cost = fields.Float(string="U. Cost / OH",compute="update_cost_prices")
    total_cost = fields.Float(string="T. Cost / OH",compute="update_cost_prices")
    unit_selling_price = fields.Float(string="U. Selling Price",compute="update_selling_prices")
    total_selling_price = fields.Float(string="T. Selling Price",compute="update_selling_prices")
    condition = fields.Char(string="Condition")
    remarks = fields.Text(string="Remarks")

    @api.depends('currency_id','cost_currency_id')
    def convert_currency(self):
        for record in self:
            if record.cost_currency_id and record.currency_id:
                # Using Odoo's currency conversion methods
                converted_amount = record.env['res.currency']._compute(record.currency_id, record.cost_currency_id, 1)
                record.converted_price = converted_amount
            else:
                record.converted_price = 1

    @api.depends('section_system_id.section_id.cost_id.currency_id')
    def fetch_cost_currency_id(self):
        for record in self:
            record.cost_currency_id = record.section_system_id.section_id.cost_id.currency_id

    @api.depends('unit_list_price','discount','quantity','currency_id','converted_price')
    def update_list_prices(self):
        for record in self:
            discount=0.0
            custom = record.custom*100
            if record.discount >=0.0:
                discount= record.discount
            if discount>0:
                record.list_price_in_sar = ((record.unit_list_price*(1-discount/100))*(record.converted_price))
            else:
                record.list_price_in_sar = (record.unit_list_price*(record.converted_price))

            record.total_list_price = record.list_price_in_sar * record.quantity

        # for record in self:
        #     record.unit_landed_cost = (record.list_price_in_sar * (
        #                 1 + record.section_system_id.line_custom + record.section_system_id.line_shipping))
        #     record.total_landed_cost = record.unit_landed_cost * record.quantity
    
    @api.depends('section_system_id.line_custom','list_price_in_sar','section_system_id.line_shipping','quantity')
    def update_landed_costs_prices(self):
        for record in self:
            record.unit_landed_cost = (record.list_price_in_sar*(1+record.section_system_id.line_custom+record.section_system_id.line_shipping))
            record.total_landed_cost = record.unit_landed_cost*record.quantity

    @api.depends('unit_landed_cost','section_system_id.line_oh','section_system_id.line_material_risk','quantity')
    def update_cost_prices(self):
        for record in self:
            record.unit_cost = (record.unit_landed_cost *(1+record.section_system_id.line_oh+record.section_system_id.line_material_risk))
            record.total_cost = record.unit_cost* record.quantity

    @api.depends('unit_cost','section_system_id.line_margin','quantity', 'section_system_id.line_ceiling')
    def update_selling_prices(self):
        for record in self:
            margin = 1 - record.section_system_id.line_margin
            ceiling = record.section_system_id.line_ceiling * 100
            unit_cost = record.unit_cost / margin
            usp = math.ceil(unit_cost) * 0
            if ceiling:
                usp = math.ceil(unit_cost / ceiling) * ceiling
            record.unit_selling_price = usp
            record.total_selling_price = record.unit_selling_price*record.quantity

    def view_edit_line(self):
        return {
            'name': 'System Group Detail',
            'type': 'ir.actions.act_window',
            'res_model': 'system.group',
            'target': 'new',
            'view_mode': 'form',
            'res_id': self.id,
        }
    @api.depends('quantity','unit_selling_price')
    def update_total_unit_price(self):
        for line in self:
            line.unit_price = line.unit_selling_price
            line.total_price = line.unit_price*line.quantity

    # @api.model
    # def default_get(self, fields):
    #     res = super().default_get(fields)
    #     res.update({
    #             'custom': self._context.get('default_line_custom'),
    #             'shipping': self._context.get('default_line_shipping'),
    #             'oh': self._context.get('default_line_oh'),
    #             'margin': self._context.get('default_line_margin'),
    #             'material_risk': self._context.get('default_line_material_risk'),
    #             'installation': self._context.get('default_line_installation'),
    #         })
    #     return res

    @api.onchange('product_id')
    def onchange_product(self):
        for line in self:
            brand_id = False
            group_id = False
            name = ''
            if line.product_id:
                brand_id = line.product_id.product_brand and line.product_id.product_brand.id
                group_id = line.product_id.product_group and line.product_id.product_group.id
                name = line.product_id.display_name
            line.brand_id = brand_id
            line.group_id = group_id
            line.name = name

    def view_edit_material_line(self):
        view_id = self.env.ref('costing_sheet.material_sheet_line_view_form')
        res_id = self.env['material.sheet.line'].search([('system_id','=',self.system_id.id)])
        return {
            'name': 'Material Lines',
            'type': 'ir.actions.act_window',
            'res_model': 'material.sheet.line',
            'view_mode': 'form',
            'view_id': view_id.id,
            'target': 'current',
            'res_id': res_id.id,
        }
        pass

    @api.depends('section_system_id')
    def _get_product_pricing_vals(self):
        for line in self:
            if line.section_system_id:
                line.custom = line.section_system_id.line_custom
                line.shipping = line.section_system_id.line_shipping
                line.oh = line.section_system_id.line_oh
                line.margin = line.section_system_id.line_margin
                line.material_risk = line.section_system_id.line_margin
                line.installation = line.section_system_id.line_installation
                line.ceiling = line.section_system_id.line_ceiling
            else:
                line.custom = 0.0
                line.shipping = 0.0
                line.oh = 0.0
                line.margin = 0.0
                line.material_risk = 0.0
                line.installation = 0.0
                line.installation = 0.0
                line.ceiling = 0.0
   
    @api.depends('group_id','brand_id')
    def _get_product_pricing_group(self):
        for record in self:
            product_pricing_group = self.env['product.group.settings'].search(
                    [('brand_id', '=', record.brand_id.id),
                     ('group_id', '=', record.group_id.id)], limit=1)
            record.product_pricing_group = product_pricing_group

    # @api.onchange('product_id')
    # def update_unit_price(self):
    #     for record in self:
    #         product_pricing_group = self.env['product.pricing.settings'].search(
    #                 [('product_pricing_group', '=', record.product_pricing_group)], limit=1)
    #         record.unit_price = product_pricing_group.unit_price

    @api.onchange('product_id')
    def update_currency_id(self):
        for record in self:
            record.currency_id = record.section_system_id.currency_id


    
    @api.model_create_multi
    @api.returns('self', lambda value: value.id)
    def create(self, vals_list):
        groups = super(Group, self).create(vals_list)
        for rec in groups:
            material_sheet = self.env["material.sheet"].search([('cost_id','=',rec.system_id.cost_id.id)],limit=1)
            if not material_sheet:
                material_sheet = self.env["material.sheet"].create([{'cost_id':rec.system_id.cost_id.id}])
            material_sheet.line_ids = [(0,0,{'system_id':rec.system_id.id,'group_id':rec.id,'material_id':material_sheet.id})]
        return groups

                
class Overview(models.Model):
    _name = "system.overview"
    _description = "overview data"

    name = fields.Char(string="Description")
    system_id = fields.Many2one("system.system", ondelete='cascade')
    installation_system_id = fields.Many2one("system.system", ondelete='cascade')

    product_id = fields.Many2one('product.product', string='Product')
    brand_id = fields.Many2one('product.brand', string='Brand')
    group_id = fields.Many2one('product.group', string='Group')
    quantity = fields.Integer(string="Qty", default=1)
    unit_price = fields.Float(string="Unit Price")
    total_price = fields.Float(string="Total Price")

    currency_id = fields.Many2one("res.currency", string="Currency")
    unit_list_price = fields.Monetary(string="Unit List Price", currency_field='currency_id')
    list_price_in_sar = fields.Monetary(string="List Price in SAR")
    total_list_price = fields.Float(string="Total List Price")
    unit_landed_cost = fields.Float(string="U. Landed Cost")
    total_landed_cost = fields.Float(string="T. Landed Cost")
    unit_cost = fields.Float(string="U. Cost / OH")
    total_cost = fields.Float(string="T. Cost / OH")
    unit_selling_price = fields.Float(string="U. Selling Price")
    total_selling_price = fields.Float(string="T. Selling Price")

    company_id = fields.Many2one('res.company', 'Company', index=True,
                                 default=lambda self: self.env.company)

    display_type = fields.Selection(
        selection=[
            ('line_section', "Section"),
            ('line_note', "Note"),
        ],
        default=False)

