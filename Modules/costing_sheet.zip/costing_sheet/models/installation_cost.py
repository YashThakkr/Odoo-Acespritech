import math

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from dis import dis

class PT(models.Model):
    _inherit = "project.type"
    
    default_install_line_data = fields.One2many("install.line.data", 'project_type_id')

    note = fields.Text('Terms and Conditions')

class InstallationSheet(models.Model):
    _name = "install.sheet"
    _description = "costing sheet for installation before quotation"

    name = fields.Char('Name', index=True, required=True, readonly=True, copy=False, default="New")
    company_id = fields.Many2one('res.company', 'Company', required=True, index=True,
                                 default=lambda self: self.env.company)
    
    
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", 'New') == "New":
                vals['name'] = self.env['ir.sequence'].next_by_code('seq.install.sheet') or 'New'
        cost = super(InstallationSheet, self).create(vals_list)
        return cost

    cost_id = fields.Many2one("cost.sheet", string="Cost Sheet")
    currency_id = fields.Many2one("res.currency", related="cost_id.currency_id")
    lead_id = fields.Many2one("crm.lead", related="cost_id.lead_id")
    sheet_rev = fields.Char(related="cost_id.revision")
    project_name = fields.Char(related="cost_id.project_name")
    project_type = fields.Many2one(related="cost_id.project_type")

    discount = fields.Float("Discount %", inverse="update_summary_lines")
    line_ids = fields.One2many("install.sheet.line", "installation_id", "Installation Line")

    def update_summary_lines(self):
        total_net,total_dicount, total_land, total_oh_cost, total_selling_price = 0, 0, 0, 0 ,0
        cost = self.env["cost.sheet"].search([("id", "=", self.cost_id.id)])
        if cost:
            sheet_line = self.env["install.sheet.line"].search([("installation_id", "=", self.id)])
            disc = sheet_line.installation_id.discount /100
            for line in sheet_line:
                line_data = self.env["install.line.data"].search([("installation_line_id", "=", line.id)])
                for data in line_data:
                    total_net += data.total_price
                    total_land += data.total_landed_price
                    total_oh_cost += data.total_oh_cost
                    total_selling_price += data.final_total
                    total_dicount += (data.final_total * disc)
            fetch_summary = self.env["cost.sheet.summary"].search(
                [("cost_id", "=", cost.id), ("name", "=", "Labor")])
            if not fetch_summary:
                self.env["cost.sheet.summary"].create({"cost_id": cost.id, "name": "Labor", "net_cost": total_net,
                                                       "land_cost": total_land, "overhead": total_oh_cost - total_land,
                                                       "land_oh_cost": total_land + (total_oh_cost - total_land),
                                                       "selling_price": total_selling_price, "discount": total_dicount,
                                                       "net_price": total_selling_price - total_dicount,
                                                       'seq':1,
                                                       "net_profit": (total_selling_price - total_dicount) - (
                                                               total_oh_cost - total_land) - total_land})
            else:
                fetch_summary.write({ "net_cost": total_net,"land_cost": total_land,
                                    "overhead": total_oh_cost - total_land,
                                    "land_oh_cost": total_land + (total_oh_cost - total_land),
                                    "selling_price": total_selling_price, "discount": total_dicount,
                                    "net_price": total_selling_price - total_dicount,
                                    "net_profit": (total_selling_price - total_dicount) - (total_oh_cost - total_land) - total_land})
        cost.update_summary()

    def write(self, values):
        """Override default Odoo write function and extend."""
        # Do your custom logic here
        res = super(InstallationSheet, self).write(values)
        self.update_summary_lines()
        
        return res


class InstallationSheetLine(models.Model):
    _name = "install.sheet.line"
    _description = "installation sheet lines"

    installation_id = fields.Many2one("install.sheet", string="Material Sheet", ondelete='cascade')
    company_id = fields.Many2one(related='installation_id.company_id', string='Company', store=True, readonly=True,
                                 index=True)
    system_id = fields.Many2one("system.system", string="System", required=True)
    install_line_data = fields.One2many("install.line.data", "installation_line_id", "Lines Data")
    currency_id = fields.Many2one("res.currency", related="installation_id.currency_id")
    brand_id = fields.Many2one('product.brand',"Brand")
    quote_brand = fields.Char("Quote Brand",related="brand_id.name",store=1)
    quote_description = fields.Text("Quote Description", default='System Installation', required=True)
    quote_qty = fields.Integer("Quote Qty")
    quote_unit = fields.Many2one("uom.uom", string="Quote Unit")
    quote_model = fields.Char("Quote Model")
    quote_product_id = fields.Many2one("product.product", 'Quote Product')
    oh = fields.Float("OH %", related="system_id.oh")
    margin = fields.Float("Margin%:", related="system_id.margin")
    risk = fields.Float("Risk %", related="system_id.risk")
    attachment_ids = fields.Many2many("ir.attachment", string="Attachments")
    
    
    
class InstallationSheetLineData(models.Model):
    _name = "install.line.data"
    _description = "line data"

    installation_line_id = fields.Many2one("install.sheet.line", ondelete='cascade')
    company_id = fields.Many2one(related='installation_line_id.company_id', string='Company', store=True, readonly=True,
                                 index=True)
    product_id = fields.Many2one(
        'product.product', string='Product',
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",
        change_default=True, ondelete='restrict', check_company=True)  # Unrequired company
    product_template_id = fields.Many2one(
        'product.template', string='Product Template',
        related="product_id.product_tmpl_id")
    cs_brand = fields.Many2one("product.brand", string="Brand")
    model = fields.Char("Model")
    description = fields.Text("Description", required=True)
    qty = fields.Integer("Qty", default=0)
    unit = fields.Many2one("uom.uom", string="Unit")

    remarks = fields.Char("Remarks")
    discount = fields.Char("Discount")
    project_type_id = fields.Many2one("project.type")
    
    @api.onchange("discount")
    def onchange_discount(self):
        for rec in self:
            try:
                rec.discount = f"{float(rec.discount)}%"
            except  Exception:
                raise UserError(_("Enter discount as float number"))

    currency_id = fields.Many2one('res.currency',
                                  string='Currency', readonly=False)
    currency_rate = fields.Float("Currency Exchange", compute="_exchange_rate", store=True, readonly=True,
                                 digits=(12, 12))

    @api.depends("currency_id")
    def _exchange_rate(self):
        for rec in self:
            try:
                base_currency = rec.installation_line_id.installation_id.cost_id.currency_id
                currency_company_id = self.company_id.currency_id
                if base_currency and rec.currency_id:
                    if base_currency.id == rec.currency_id.id:
                        rec.currency_rate = 1
                    else:
                        if base_currency.id == currency_company_id.id:
                            rate_id = rec.env["res.currency.rate"].search([("currency_id", "=", rec.currency_id.id),
                                                                           ("company_id", "=", self.company_id.id),
                                                                           ("name", "<=",
                                                                            rec.installation_line_id.installation_id.cost_id.issue_date)],
                                                                          limit=1, order='name desc')
                            rec.currency_rate = rate_id.rate
                        else:
                            base_rate_id = rec.env["res.currency.rate"].search([("currency_id", "=", base_currency.id),
                                                                                ("company_id", "=", self.company_id.id),
                                                                                ("name", "<=",
                                                                                 rec.installation_line_id.installation_id.cost_id.issue_date)],
                                                                               limit=1, order='name desc')
                            base_rate = base_rate_id.rate
                            rate_id = rec.env["res.currency.rate"].search([("currency_id", "=", rec.currency_id.id),
                                                                           ("company_id", "=", self.company_id.id),
                                                                           ("name", "<=",
                                                                            rec.installation_line_id.installation_id.cost_id.issue_date)],
                                                                          limit=1, order='name desc')
                            rate = rate_id.rate
                            rec.currency_rate = rate / base_rate
            except Exception as e:
                raise UserError(_(str(e)))

    unit_price = fields.Float("Unit List/Unit Net Price")
    base_unit_price = fields.Float("Unit List /Unit Net price in CS Base Currency", compute="_price_exchange_rate",
                                   store=True, readonly=True, default=0)

    @api.depends("unit_price", "currency_rate", "discount")
    def _price_exchange_rate(self):
        for rec in self:
            try:
                if rec.unit_price and rec.currency_rate:
                    discount = 0
                    if rec.discount:
                        discount = float(rec.discount.replace("%", ""))
                    rec.base_unit_price = (rec.unit_price / rec.currency_rate) * (1 - (discount / 100))
            except Exception as e:
                raise UserError(_(str(e)))

    # calculate
    total_price = fields.Float("Total Net Price", compute="_compute_total", inverse="_inverse_update_summary",
                               store=True, readonly=True, default=0)
    
    def _inverse_update_summary(self):
        self.installation_line_id.installation_id.update_summary_lines()

    @api.depends("base_unit_price", "qty")
    def _compute_total(self):
        for rec in self:
            if rec.base_unit_price and rec.qty:
                rec.total_price = rec.base_unit_price * rec.qty

    total_risk_cost = fields.Float("T.Risk Cost", compute="_compute_total_risk",
                                   store=True, readonly=True, default=0)

    @api.depends("total_price", "installation_line_id","installation_line_id.risk")
    def _compute_total_risk(self):
        for rec in self:
            if rec.total_price and rec.installation_line_id:
                risk = (rec.installation_line_id.risk / 100)
                rec.total_risk_cost = rec.total_price * risk
                rec.installation_line_id.installation_id.update_summary_lines()

    total_landed_cost = fields.Float("T.Landed Cost", compute="_onchange_land", inverse="_inverse_update_summary",readonly=True)

    @api.depends("base_unit_price")
    def _onchange_land(self):
        for rec in self:
            if rec.base_unit_price:
                rec.total_landed_cost = rec.base_unit_price
            else:
                rec.total_landed_cost = 0

    total_landed_price = fields.Float("T.Landed Price", compute="_compute_total_price",
                                      store=True, readonly=True, default=0)

    @api.depends("total_landed_cost", "qty")
    def _compute_total_price(self):
        for rec in self:
            if rec.total_landed_cost and rec.qty:
                rec.total_landed_price = rec.total_landed_cost * rec.qty
                rec.installation_line_id.installation_id.update_summary_lines()
                
    unit_oh_cost = fields.Float("U.Cost/OH", compute="_compute_unit_oh", inverse="_inverse_update_summary",
                                store=True, readonly=True, default=0)

    @api.depends("total_landed_cost", "installation_line_id.oh", "installation_line_id.risk")
    def _compute_unit_oh(self):
        for rec in self:
            if rec.total_landed_cost and rec.installation_line_id:
                oh = (rec.installation_line_id.oh / 100)
                risk = (rec.installation_line_id.risk / 100)
                rec.unit_oh_cost = rec.total_landed_cost * (1 + oh + risk)
                rec.installation_line_id.installation_id.update_summary_lines()
                
    total_oh_cost = fields.Float("T.Cost/OH", compute="_compute_total_oh",inverse="_inverse_update_summary",
                                 store=True, readonly=True, default=0)

    @api.depends("qty", "unit_oh_cost")
    def _compute_total_oh(self):
        for rec in self:
            if rec.qty and rec.unit_oh_cost:
                rec.total_oh_cost = rec.qty * rec.unit_oh_cost
                rec.installation_line_id.installation_id.update_summary_lines()
                
    unit_selling_price = fields.Float("U.Selling Price", compute="_compute_unit_selling",
                                      store=True, readonly=True, default=0)

    @api.depends("unit_oh_cost","installation_line_id.margin")
    def _compute_unit_selling(self):
        for rec in self:
            if rec.unit_oh_cost and rec.installation_line_id:
                margin = rec.installation_line_id.margin / 100
                result = rec.unit_oh_cost / (1 - margin)
                rec.unit_selling_price = math.ceil(result)
                rec.installation_line_id.installation_id.update_summary_lines()
                rec.onchange_final_unit()
                
    total_selling_price = fields.Float("T.Selling Price", compute="_compute_total_selling",
                                       store=True, readonly=True, default=0)

    @api.depends("unit_selling_price", "qty")
    def _compute_total_selling(self):
        for rec in self:
            if rec.unit_selling_price and rec.qty:
                rec.total_selling_price = rec.unit_selling_price * rec.qty
                rec.installation_line_id.installation_id.update_summary_lines()
                
    final_unit = fields.Float("Final U.P")  # default like U. Selling Price

    @api.onchange("unit_selling_price")
    def onchange_final_unit(self):
        for rec in self:
            if rec.unit_selling_price:
                rec.final_unit = rec.unit_selling_price

    final_total = fields.Float("Final T.P", compute="_compute_final_total",inverse="_inverse_update_summary",
                               store=True, readonly=True, default=0)

    @api.depends("final_unit", "qty")
    def _compute_final_total(self):
        for rec in self:
            if rec.final_unit and rec.qty:
                rec.final_total = rec.final_unit * rec.qty
                rec.installation_line_id.installation_id.update_summary_lines()