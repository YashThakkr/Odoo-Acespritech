{
    'name': "Costing Module",
    "version": "16.0.1.0.1",
    "category": "Sale",
    'description': """
       Calculate the Costing method for each system , group and items from lead to sales order line
    """,
    'author': "Moath Hasan",
    'email': "Moathhasan64@outlook.com",
    'license': 'AGPL-3',
    'images': [],
    'depends': ['base', 'web', 'custom_crm', 'report_xlsx', 'project_management','prod_desc_bpc',"project"],
    'data': [
        'wizards/create_rfq.xml',
        'security/security.xml',
        'security/ir.model.access.csv',

        "reports/costing_report_view.xml",
        "reports/install_sheet_report.xml",
        "reports/material_sheet_report.xml",

        "wizards/cancel_cost_view.xml",
        "wizards/cost_revision_view.xml",
        "wizards/cost_to_quote_view.xml",

        'views/data.xml',
        # 'views/asset.xml',
        'views/cost_sequence_num.xml',
        "views/cost_sheet_view.xml",
        "views/cost_menu.xml",
        "views/crm_lead_view.xml",
        "views/installation_sheet_view.xml",
        "views/material_sheet_view.xml",
        "views/product_pricing_view.xml",
        "views/account_move_view.xml",
        "views/sale_order_views.xml",
        "views/purchase_view.xml",
        "views/system_section_views.xml",
        "views/system_group_views.xml",
        "views/system_system_view.xml",
        'views/menu.xml',

    ],
    'assets': {
        'web.assets_backend': [
            'costing_sheet/static/src/css/style.css',
        ],
    },
    'application': True,
    'installable': True,

}
