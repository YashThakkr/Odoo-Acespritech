odoo.define('costing_sheet.brand_section_note_widget', function (require) {
    "use strict";

    const FormController = require('web.FormController');

    FormController.include({
        async renderButtons($node) {
            await this._super($node);
            const self = this;
            if (this.$buttons) {
                const $brandIdField = this.$buttons.find('.o_field_widget[name=brand_id]');
                if ($brandIdField.length) {
                    const $brandSectionNoteButton = $('<button>', {
                        class: 'o_button o_brand_section_note_button',
                        text: 'Add Section for Brand',
                        on: {
                            click: function () {
                                self._onBrandSectionNoteButtonClick();
                            }
                        }
                    });
                    $brandIdField.after($brandSectionNoteButton);
                }
            }
        },
        _onBrandSectionNoteButtonClick() {
            // Your logic for handling sections for the brand_id field
            // This function is called when your custom button is clicked
        },
    });
});
