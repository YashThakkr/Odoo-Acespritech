from odoo import models


class MaterialSheetReport(models.AbstractModel):
    _name = "report.costing_sheet.report_material_xls"
    _inherit = "report.report_xlsx.abstract"
    _description = "material sheet report"

    def generate_xlsx_report(self, workbook, data, model):
        values = {}
        if model:
            lines = []
            final_unit = 0
            final_total = 0
            for line in model.line_ids:
                system = dict()
                system["system"] = line.system_id.name
                system["group"] = line.group_id.name
                lines.append(system)
                for data in line.line_ids:
                    final_unit += data.final_unit
                    final_total += data.final_total
            values['lines'] = lines
            values["name"] = model.name
            values["cost"] = model.cost_id.name
            values["lead"] = model.lead_id.name
            values["revision"] = model.sheet_rev
            values["project_name"] = model.project_name
            values["discount"] = model.discount

            project_type = "Material & Installation"
            if model.project_type.name == "mat":
                project_type = "Material"
            elif model.project_type.name == "install":
                project_type = "Installation"
            values['project_type'] = project_type

            material_format = workbook.add_format(
                {'bg_color': 'black', 'align': 'center', 'font_size': 14,
                 'font_color': 'white', 'border': 1})
            header_format = workbook.add_format({
                'align': 'center', 'font_size': 13, 'bold': True, 'border': 1})
            format = workbook.add_format({
                'align': 'center', 'font_size': 13, 'border': 1})
            table_header_left = workbook.add_format(
                {'bg_color': 'black', 'align': 'left', 'font_size': 12,
                 'font_color': 'white'})
            table_row_left = workbook.add_format(
                {'align': 'left', 'font_size': 12, 'border': 1})
            table_header_right = workbook.add_format(
                {'bg_color': 'black', 'align': 'right', 'font_size': 12,
                 'font_color': 'white', 'border': 1})
            table_row_right = workbook.add_format(
                {'align': 'right', 'font_size': 12, 'border': 1})

            worksheet = workbook.add_worksheet("Material Sheet")

            worksheet.merge_range('A5:H5', 'Material Sheet :- ' + values['name'], material_format)

            worksheet.merge_range('A7:B7', 'Cost', header_format)
            worksheet.merge_range('C7:D7', values['cost'], format)
            worksheet.merge_range('A8:B8', 'Lead', header_format)
            worksheet.merge_range('C8:D8', values['lead'], format)
            worksheet.merge_range('A9:B9', 'Project', header_format)
            worksheet.merge_range('C9:D9', values['project_name'], format)
            worksheet.merge_range('A12:B12', 'Final Total', header_format)
            worksheet.merge_range('C12:D12', final_total, format)
            worksheet.merge_range('A13:B13', 'Final Unit', header_format)
            worksheet.merge_range('C13:D13', final_unit, format)


            worksheet.merge_range('A6:H6', '')

            worksheet.merge_range('E7:F7', 'Version Number', header_format)
            worksheet.merge_range('G7:H7', values['revision'], format)
            worksheet.merge_range('E8:F8', 'Project Type', header_format)
            worksheet.merge_range('G8:H8', values['project_type'], format)
            worksheet.merge_range('E9:F9', 'Discount', header_format)
            worksheet.merge_range('G9:H9', values['discount'], format)

            worksheet.merge_range('A14:I14', '')
            worksheet.set_column('A:A', 40)
            worksheet.set_column('B:B', 15)
            worksheet.set_column('C:C', 15)
            worksheet.set_column('D:D', 15)
            worksheet.set_column('E:E', 15)
            worksheet.set_column('F:F', 15)
            worksheet.set_column('G:G', 15)
            worksheet.set_column('H:H', 15)

            row = 14
            if values["lines"]:
                worksheet.write(row, 0, 'System', table_header_left)
                worksheet.write(row, 1, 'Group', table_header_right)
                row += 1
                for line in values["lines"]:
                    worksheet.write(row, 0, line["system"], table_row_left)
                    worksheet.write(row, 1, line["group"], table_row_right)
                    row += 1


class MaterialLineSheetReport(models.AbstractModel):
    _name = "report.costing_sheet.report_material_line_xls"
    _inherit = "report.report_xlsx.abstract"
    _description = "material line sheet report"

    def generate_xlsx_report(self, workbook, data, model):
        values = {}
        if model:
            lines = []
            for line in model.line_ids:
                product = ""
                if line.product_id:
                    product = line.product_id.display_name
                data = {"product": product, "cs_brand": line.cs_brand.name,
                        "cs_model": line.cs_model,
                        "cs_description": line.cs_description, "cs_qty": line.cs_qty, "cs_unit": line.cs_unit.name,
                        "quote_brand": line.quote_brand, "quote_model": line.quote_model,
                        "quote_description": line.quote_description, "quote_qty": line.quote_qty,
                        "quote_unit": line.quote_unit.name, "remarks": line.remarks, "discount": line.discount,
                        "stock_qty": line.stock_qty, "reserved_qty": line.forcasted_qty,
                        "currency": line.currency_id.name,
                        "currency_rate": line.currency_rate, "unit_price": line.unit_price,
                        "base_unit_price": line.base_unit_price,
                        "total_price": line.total_price, "total_custom_price": line.total_custom_price,
                        "total_shipping_cost": line.total_shipping_cost,
                        "total_risk_cost": line.total_risk_cost, "total_landed_cost": line.total_landed_cost,
                        "total_landed_price": line.total_landed_price, "unit_oh_cost": line.unit_oh_cost,
                        "total_oh_cost": line.total_oh_cost, "unit_selling_price": line.total_selling_price,
                        "final_unit": line.final_unit, "final_total": line.final_total}
                lines.append(data)
            values["lines"] = lines

            values["name"] = model.material_id.name
            values["cost"] = model.material_id.cost_id.name
            values["lead"] = model.material_id.lead_id.name
            values["revision"] = model.material_id.sheet_rev
            values["project_name"] = model.material_id.project_name
            values["discount"] = model.material_id.discount

            project_type = "Material & Installation"
            if model.material_id.project_type.name == "mat":
                project_type = "Material"
            elif model.material_id.project_type.name == "install":
                project_type = "Installation"
            values['project_type'] = project_type

            material_format = workbook.add_format(
                {'bg_color': 'black', 'align': 'center', 'font_size': 14,
                 'font_color': 'white', 'border': 1})
            header_format = workbook.add_format({
                'align': 'center', 'font_size': 13, 'bold': True, 'border': 1})
            format = workbook.add_format({
                'align': 'center', 'font_size': 13, 'border': 1})
            table_header = workbook.add_format(
                {'bg_color': 'black', 'align': 'center', 'font_size': 12,
                 'font_color': 'white'})
            table_row = workbook.add_format(
                {'align': 'center', 'font_size': 12, 'border': 1})

            worksheet = workbook.add_worksheet("Material Sheet Line")

            worksheet.merge_range('A5:H5', 'Material Sheet :- ' + values['name'], material_format)

            worksheet.merge_range('A7:B7', 'Cost', header_format)
            worksheet.merge_range('C7:D7', values['cost'], format)
            worksheet.merge_range('A8:B8', 'Lead', header_format)
            worksheet.merge_range('C8:D8', values['lead'], format)
            worksheet.merge_range('A9:B9', 'Project', header_format)
            worksheet.merge_range('C9:D9', values['project_name'], format)

            worksheet.merge_range('A6:H6', '')

            worksheet.merge_range('E7:F7', 'Version Number', header_format)
            worksheet.merge_range('G7:H7', values['revision'], format)
            worksheet.merge_range('E8:F8', 'Project Type', header_format)
            worksheet.merge_range('G8:H8', values['project_type'], format)
            worksheet.merge_range('E9:F9', 'Discount', header_format)
            worksheet.merge_range('G9:H9', values['discount'], format)

            worksheet.merge_range('A10:I10', '')
            worksheet.set_column('A:A', 40)
            worksheet.set_column('B:B', 15)
            worksheet.set_column('C:C', 15)
            worksheet.set_column('D:D', 15)
            worksheet.set_column('E:E', 15)
            worksheet.set_column('F:F', 15)
            worksheet.set_column('G:G', 15)
            worksheet.set_column('H:H', 15)

            row = 12
            if values["lines"]:
                worksheet.write(row, 0, 'Product', table_header)
                worksheet.write(row, 1, 'CS Brand', table_header)
                worksheet.write(row, 2, 'CS Model', table_header)
                worksheet.write(row, 3, 'CS Description', table_header)
                worksheet.write(row, 4, 'CS Qty', table_header)
                worksheet.write(row, 5, 'CS Unit', table_header)
                worksheet.write(row, 6, 'Quote Brand', table_header)
                worksheet.write(row, 7, 'Quote Model', table_header)
                worksheet.write(row, 8, 'Quote Description', table_header)
                worksheet.write(row, 9, 'Quote Qty', table_header)
                worksheet.write(row, 10, 'Quote Unit', table_header)
                worksheet.write(row, 11, 'CS Remarks', table_header)
                worksheet.write(row, 12, 'Discount', table_header)
                worksheet.write(row, 13, 'Stock QTY', table_header)
                worksheet.write(row, 14, 'Reserved QTY', table_header)
                worksheet.write(row, 15, 'Currency', table_header)
                worksheet.write(row, 16, 'Currency Exchange', table_header)
                worksheet.write(row, 17, 'Unit List/Unit Net Price', table_header)
                worksheet.write(row, 18, 'Unit List /Unit Net price in CS Base Currency', table_header)
                worksheet.write(row, 19, 'Total Net Price', table_header)
                worksheet.write(row, 20, 'T.Custom Cost', table_header)
                worksheet.write(row, 21, 'T.Shipping Cost', table_header)
                worksheet.write(row, 22, 'T.Risk Cost', table_header)
                worksheet.write(row, 23, 'T.Landed Cost', table_header)
                worksheet.write(row, 24, 'U.Cost/OH', table_header)
                worksheet.write(row, 25, 'T.Cost/OH', table_header)
                worksheet.write(row, 26, 'U.Selling Price', table_header)
                worksheet.write(row, 27, 'T.Selling Price', table_header)
                worksheet.write(row, 28, 'Final U.P', table_header)
                worksheet.write(row, 29, 'Final T.P', table_header)
                row += 1
                for i in range(1, 30):
                    worksheet.set_column(row, i, 15)
                for line in values["lines"]:
                    worksheet.write(row, 0, line["product"], table_row)
                    worksheet.write(row, 1, line["cs_brand"], table_row)
                    worksheet.write(row, 2, line["cs_model"], table_row)
                    worksheet.write(row, 3, line["cs_description"], table_row)
                    worksheet.write(row, 4, line["cs_qty"], table_row)
                    worksheet.write(row, 5, line["cs_unit"], table_row)
                    worksheet.write(row, 6, line["quote_brand"], table_row)
                    worksheet.write(row, 7, line["quote_model"], table_row)
                    worksheet.write(row, 8, line["quote_description"], table_row)
                    worksheet.write(row, 9, line["quote_qty"], table_row)
                    worksheet.write(row, 10, line["quote_unit"], table_row)
                    worksheet.write(row, 11, line["remarks"], table_row)
                    worksheet.write(row, 12, line["discount"], table_row)
                    worksheet.write(row, 13, line["stock_qty"], table_row)
                    worksheet.write(row, 14, line["reserved_qty"], table_row)
                    worksheet.write(row, 15, line["currency"], table_row)
                    worksheet.write(row, 16, line["currency_rate"], table_row)
                    worksheet.write(row, 17, line["unit_price"], table_row)
                    worksheet.write(row, 18, line["base_unit_price"], table_row)
                    worksheet.write(row, 19, line["total_price"], table_row)
                    worksheet.write(row, 20, line["total_custom_price"], table_row)
                    worksheet.write(row, 21, line["total_shipping_cost"], table_row)
                    worksheet.write(row, 22, line["total_risk_cost"], table_row)
                    worksheet.write(row, 23, line["total_landed_cost"], table_row)
                    worksheet.write(row, 24, line["total_landed_price"], table_row)
                    worksheet.write(row, 25, line["unit_oh_cost"], table_row)
                    worksheet.write(row, 26, line["total_oh_cost"], table_row)
                    worksheet.write(row, 27, line["unit_selling_price"], table_row)
                    worksheet.write(row, 28, line["final_unit"], table_row)
                    worksheet.write(row, 29, line["final_total"], table_row)

                    row += 1
