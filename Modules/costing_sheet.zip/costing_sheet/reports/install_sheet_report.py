from odoo import models


class InstallSheetReport(models.AbstractModel):
    _name = "report.costing_sheet.report_install_xls"
    _inherit = "report.report_xlsx.abstract"
    _description = "install sheet report"

    def generate_xlsx_report(self, workbook, data, model):
        values = {}
        if model:
            lines = []
            final_unit = 0
            final_total = 0
            for line in model.line_ids:
                system = dict()
                system["system"] = line.system_id.name
                product = ""
                #===============================================================
                # if line.product_id:
                #     product = line.product_id.display_name
                #===============================================================
                system["product"] = product
                system["brand"] = line.quote_brand
                system["description"] = line.quote_description
                system["qty"] = line.quote_qty
                system["uom"] = line.quote_unit.name
                system["model"] = line.quote_model
                lines.append(system)
                for data in line.install_line_data:
                    final_unit += data.final_unit
                    final_total += data.final_total
            values["lines"] = lines

            values["name"] = model.name
            values["cost"] = model.cost_id.name
            values["lead"] = model.lead_id.name
            values["revision"] = model.sheet_rev
            values["project_name"] = model.project_name
            #===================================================================
            # values["oh"] = model.oh
            # values["margin"] = model.margin
            # values["risk"] = model.risk
            #===================================================================
            values["discount"] = model.discount

            project_type = "Material & Installation"
            if model.project_type.name == "mat":
                project_type = "Material"
            elif model.project_type.name == "install":
                project_type = "Installation"
            values['project_type'] = project_type

            install_format = workbook.add_format(
                {'bg_color': 'black', 'align': 'center', 'font_size': 14,
                 'font_color': 'white', 'border': 1})
            header_format = workbook.add_format({
                'align': 'center', 'font_size': 13, 'bold': True, 'border': 1})
            format = workbook.add_format({
                'align': 'center', 'font_size': 13, 'border': 1})
            table_header_left = workbook.add_format(
                {'bg_color': 'black', 'align': 'left', 'font_size': 12,
                 'font_color': 'white'})
            table_row_left = workbook.add_format(
                {'align': 'left', 'font_size': 12, 'border': 1})
            table_header_right = workbook.add_format(
                {'bg_color': 'black', 'align': 'right', 'font_size': 12,
                 'font_color': 'white', 'border': 1})
            table_row_right = workbook.add_format(
                {'align': 'right', 'font_size': 12, 'border': 1})

            worksheet = workbook.add_worksheet("Installation Sheet")

            worksheet.merge_range('A5:H5', 'Installation Sheet :- ' + values['name'], install_format)

            worksheet.merge_range('A7:B7', 'Cost', header_format)
            worksheet.merge_range('C7:D7', values['cost'], format)
            worksheet.merge_range('A8:B8', 'Lead', header_format)
            worksheet.merge_range('C8:D8', values['lead'], format)
            worksheet.merge_range('A9:B9', 'Project', header_format)
            worksheet.merge_range('C9:D9', values['project_name'], format)
            worksheet.merge_range('A10:B10', 'Version Number', header_format)
            worksheet.merge_range('C10:D10', values['revision'], format)
            worksheet.merge_range('A11:B11', 'Project Type', header_format)
            worksheet.merge_range('C11:D11', values['project_type'], format)

            worksheet.merge_range('A6:H6', '')

            #===================================================================
            # worksheet.merge_range('E7:F7', 'OH', header_format)
            # worksheet.merge_range('G7:H7', values['oh'], format)
            # worksheet.merge_range('E8:F8', 'Margin', header_format)
            # worksheet.merge_range('G8:H8', values['margin'], format)
            # worksheet.merge_range('E9:F9', 'Risk', header_format)
            # worksheet.merge_range('G9:H9', values['risk'], format)
            #===================================================================
            worksheet.merge_range('E10:F10', 'Discount', header_format)
            worksheet.merge_range('G10:H10', values['discount'], format)

            worksheet.merge_range('A13:I13', '')
            worksheet.set_column('A:A', 40)
            worksheet.set_column('B:B', 15)
            worksheet.set_column('C:C', 15)
            worksheet.set_column('D:D', 15)
            worksheet.set_column('E:E', 15)
            worksheet.set_column('F:F', 15)
            worksheet.set_column('G:G', 15)
            worksheet.set_column('H:H', 15)

            row = 14
            if values["lines"]:
                worksheet.write(row, 0, 'System', table_header_left)
                worksheet.write(row, 1, 'Product', table_header_left)
                worksheet.write(row, 2, 'Brand', table_header_right)
                worksheet.write(row, 3, 'Model', table_header_right)
                worksheet.write(row, 4, 'Description', table_header_right)
                worksheet.write(row, 5, 'Quantity', table_header_right)
                worksheet.write(row, 6, 'Unit Of Measure', table_header_right)
                worksheet.write(row, 7, 'Final U.P', table_header_right)
                worksheet.write(row, 8, 'Final T.P', table_header_right)
                row += 1
                for line in values["lines"]:
                    worksheet.write(row, 0, line["system"], table_row_left)
                    worksheet.write(row, 1, line["product"], table_row_left)
                    worksheet.write(row, 2, line["brand"], table_row_right)
                    worksheet.write(row, 3, line["model"], table_row_right)
                    worksheet.write(row, 4, line["description"], table_row_right)
                    worksheet.write(row, 5, line["qty"], table_row_right)
                    worksheet.write(row, 6, line["uom"], table_row_right)
                    worksheet.write(row, 7, final_unit, table_row_right)
                    worksheet.write(row, 8, final_total, table_row_right)
                    row += 1


class InstallLineSheetReport(models.AbstractModel):
    _name = "report.costing_sheet.report_install_line_xls"
    _inherit = "report.report_xlsx.abstract"
    _description = "install line sheet report"

    def generate_xlsx_report(self, workbook, data, model):
        values = {}
        if model:
            lines = []
            for line in model.install_line_data:
                data = {"cs_brand": line.cs_brand.name, "model": line.model,
                        "description": line.description, "qty": line.qty, "unit": line.unit.name,
                        "remarks": line.remarks, "currency": line.currency_id.name,
                        "currency_rate": line.currency_rate, "unit_price": line.unit_price,
                        "base_unit_price": line.base_unit_price,
                        "total_price": line.total_price, "total_risk_cost": line.total_risk_cost,
                        "total_landed_cost": line.total_landed_cost, "total_landed_price": line.total_landed_price,
                        "unit_oh_cost": line.unit_oh_cost, "total_oh_cost": line.total_oh_cost,
                        "unit_selling_price": line.total_selling_price, "total_selling_price": line.total_selling_price,
                        "final_unit": line.final_unit, "final_total": line.final_total}
                lines.append(data)
            values["lines"] = lines

            values["name"] = model.installation_id.name
            values["cost"] = model.installation_id.cost_id.name
            values["lead"] = model.installation_id.lead_id.name
            values["revision"] = model.installation_id.sheet_rev
            values["project_name"] = model.installation_id.project_name

            values["discount"] = model.installation_id.discount
            values["oh"] = model.oh
            values["margin"] = model.margin
            values["risk"] = model.risk

            project_type = "Material & Installation"
            if model.installation_id.project_type.name == "mat":
                project_type = "Material"
            elif model.installation_id.project_type.name == "install":
                project_type = "Installation"
            values['project_type'] = project_type

            values["quote_brand"] = model.quote_brand
            values["quote_description"] = model.quote_description
            values["quote_qty"] = model.quote_qty
            values["quote_unit"] = model.quote_unit.name
            values["quote_model"] = model.quote_model

            install_format = workbook.add_format(
                {'bg_color': 'black', 'align': 'center', 'font_size': 14,
                 'font_color': 'white', 'border': 1})
            header_format = workbook.add_format({
                'align': 'center', 'font_size': 13, 'bold': True, 'border': 1})
            format = workbook.add_format({
                'align': 'center', 'font_size': 13, 'border': 1})
            table_header = workbook.add_format(
                {'bg_color': 'black', 'align': 'center', 'font_size': 12,
                 'font_color': 'white'})
            table_row = workbook.add_format(
                {'align': 'center', 'font_size': 12, 'border': 1})

            worksheet = workbook.add_worksheet("Installation Sheet Line")

            worksheet.merge_range('A5:H5', 'Installation Sheet :- ' + values['name'], install_format)

            worksheet.merge_range('A7:B7', 'Cost', header_format)
            worksheet.merge_range('C7:D7', values['cost'], format)
            worksheet.merge_range('A8:B8', 'Lead', header_format)
            worksheet.merge_range('C8:D8', values['lead'], format)
            worksheet.merge_range('A9:B9', 'Version Number', header_format)
            worksheet.merge_range('C9:D9', values['revision'], format)
            worksheet.merge_range('A10:B10', 'Project', header_format)
            worksheet.merge_range('C10:D10', values['project_name'], format)
            worksheet.merge_range('A11:B11', 'Project Type', header_format)
            worksheet.merge_range('C11:D11', values['project_type'], format)

            worksheet.merge_range('A6:H6', '')

            worksheet.merge_range('E7:F7', 'Discount', header_format)
            worksheet.merge_range('G7:H7', values['discount'], format)
            worksheet.merge_range('E8:F8', 'OH', header_format)
            worksheet.merge_range('G8:H8', values['oh'], format)
            worksheet.merge_range('E9:F9', 'Margin', header_format)
            worksheet.merge_range('G9:H9', values['margin'], format)
            worksheet.merge_range('E10:F10', 'Risk', header_format)
            worksheet.merge_range('G10:H10', values['risk'], format)
            worksheet.merge_range('E11:F11', 'Quote Brand', header_format)
            worksheet.merge_range('G11:H11', values['quote_brand'], format)
            worksheet.merge_range('E12:F12', 'Quote Description', header_format)
            worksheet.merge_range('G12:H12', values['quote_description'], format)
            worksheet.merge_range('E13:F13', 'Quote QTY', header_format)
            worksheet.merge_range('G13:H13', values['quote_qty'], format)
            worksheet.merge_range('E14:F14', 'Quote Unit', header_format)
            worksheet.merge_range('G14:H14', values['quote_unit'], format)
            worksheet.merge_range('E15:F15', 'Quote Model', header_format)
            worksheet.merge_range('G15:H15', values['quote_model'], format)

            worksheet.merge_range('A10:I10', '')
            worksheet.set_column('A:A', 40)
            worksheet.set_column('B:B', 15)
            worksheet.set_column('C:C', 15)
            worksheet.set_column('D:D', 15)
            worksheet.set_column('E:E', 15)
            worksheet.set_column('F:F', 15)
            worksheet.set_column('G:G', 15)
            worksheet.set_column('H:H', 15)

            row = 17
            if values["lines"]:
                worksheet.write(row, 0, 'CS Brand', table_header)
                worksheet.write(row, 1, 'Model', table_header)
                worksheet.write(row, 2, 'Description', table_header)
                worksheet.write(row, 3, 'Qty', table_header)
                worksheet.write(row, 4, 'Unit', table_header)
                worksheet.write(row, 5, 'Remarks', table_header)
                worksheet.write(row, 6, 'Currency', table_header)
                worksheet.write(row, 7, 'Currency Exchange', table_header)
                worksheet.write(row, 8, 'Unit List/Unit Net Price', table_header)
                worksheet.write(row, 9, 'Unit List /Unit Net price in CS Base Currency', table_header)
                worksheet.write(row, 10, 'Total Net Price', table_header)
                worksheet.write(row, 11, 'T.Risk Cost', table_header)
                worksheet.write(row, 12, 'T.Landed Cost', table_header)
                worksheet.write(row, 13, 'T.Landed Price', table_header)
                worksheet.write(row, 14, 'U.Cost/OH', table_header)
                worksheet.write(row, 15, 'T.Cost/OH', table_header)
                worksheet.write(row, 16, 'U.Selling Price', table_header)
                worksheet.write(row, 17, 'T.Selling Price', table_header)
                worksheet.write(row, 18, 'Final U.P', table_header)
                worksheet.write(row, 19, 'Final T.P', table_header)
                row += 1
                for i in range(1, 20):
                    worksheet.set_column(row, i, 20)
                for line in values["lines"]:
                    worksheet.write(row, 0, line["cs_brand"], table_row)
                    worksheet.write(row, 1, line["model"], table_row)
                    worksheet.write(row, 2, line["description"], table_row)
                    worksheet.write(row, 3, line["qty"], table_row)
                    worksheet.write(row, 4, line["unit"], table_row)
                    worksheet.write(row, 5, line["remarks"], table_row)
                    worksheet.write(row, 6, line["currency"], table_row)
                    worksheet.write(row, 7, line["currency_rate"], table_row)
                    worksheet.write(row, 8, line["unit_price"], table_row)
                    worksheet.write(row, 9, line["base_unit_price"], table_row)
                    worksheet.write(row, 10, line["total_price"], table_row)
                    worksheet.write(row, 11, line["total_risk_cost"], table_row)
                    worksheet.write(row, 12, line["total_landed_cost"], table_row)
                    worksheet.write(row, 13, line["total_landed_price"], table_row)
                    worksheet.write(row, 14, line["unit_oh_cost"], table_row)
                    worksheet.write(row, 15, line["total_oh_cost"], table_row)
                    worksheet.write(row, 16, line["unit_selling_price"], table_row)
                    worksheet.write(row, 17, line["total_selling_price"], table_row)
                    worksheet.write(row, 18, line["final_unit"], table_row)
                    worksheet.write(row, 19, line["final_total"], table_row)
                    row += 1
