from odoo import models


class CostSheetReport(models.AbstractModel):
    _name = "report.costing_sheet.report_cost_xls"
    _inherit = "report.report_xlsx.abstract"
    _description = "costing sheet report"

    def generate_xlsx_report(self, workbook, data, model):
        costing_value = {}
        if model:
            costing_system = []
            costing_summary = []
            for sys in model.system_ids:
                system = dict()
                system["system"] = sys.name
                system["groups"] = []
                for group in sys.group_ids:
                    system["groups"].append(group.name)
                costing_system.append(system)
            for suy in model.summary_ids:
                summary = dict()
                summary['summary'] = suy.name
                summary['net_cost'] = suy.net_cost
                summary['land_cost'] = suy.land_cost
                summary['overhead'] = suy.overhead
                summary['land_oh_cost'] = suy.land_oh_cost
                summary['selling_price'] = suy.selling_price
                summary['discount'] = suy.discount
                summary['net_price'] = suy.net_price
                summary['net_profit'] = suy.net_profit
                costing_summary.append(summary)
            costing_value['systems'] = costing_system
            costing_value['summary'] = costing_summary
            costing_value['name'] = model.name
            costing_value['customer'] = model.customer_id.name
            costing_value['revision'] = model.revision
            costing_value['state'] = model.state
            costing_value['date_approve'] = model.approved_date
            costing_value['lead_name'] = model.lead_id.name
            costing_value['project_name'] = model.project_name
            project_type = "Material & Installation"
            if model.project_type.name == "mat":
                project_type = "Material"
            elif model.project_type.name == "install":
                project_type = "Installation"
            costing_value['project_type'] = project_type

        cost_format = workbook.add_format(
            {'bg_color': 'black', 'align': 'center', 'font_size': 14,
             'font_color': 'white', 'border': 1})
        customer_header_format = workbook.add_format({
            'align': 'center', 'font_size': 13, 'bold': True, 'border': 1})
        customer_format = workbook.add_format({
            'align': 'center', 'font_size': 13, 'border': 1})
        table_header_left = workbook.add_format(
            {'bg_color': 'black', 'align': 'left', 'font_size': 12,
             'font_color': 'white'})
        table_row_left = workbook.add_format(
            {'align': 'left', 'font_size': 12, 'border': 1})
        table_header_right = workbook.add_format(
            {'bg_color': 'black', 'align': 'right', 'font_size': 12,
             'font_color': 'white', 'border': 1})
        table_row_right = workbook.add_format(
            {'align': 'right', 'font_size': 12, 'border': 1})

        worksheet = workbook.add_worksheet("Costing Sheet")

        worksheet.merge_range('A5:H5', 'Costing Sheet :- ' + costing_value['name'], cost_format)

        worksheet.merge_range('A7:B7', 'Customer', customer_header_format)
        worksheet.merge_range('C7:D7', costing_value['customer'], customer_format)
        worksheet.merge_range('A8:B8', 'Lead', customer_header_format)
        worksheet.merge_range('C8:D8', costing_value['lead_name'], customer_format)
        worksheet.merge_range('A9:B9', 'Project', customer_header_format)
        worksheet.merge_range('C9:D9', costing_value['project_name'], customer_format)

        worksheet.merge_range('A6:H6', '')

        worksheet.merge_range('E7:F7', 'Version Number', customer_header_format)
        worksheet.merge_range('G7:H7', costing_value['revision'], customer_format)
        worksheet.merge_range('E8:F8', 'Status', customer_header_format)
        worksheet.merge_range('G8:H8', costing_value['state'], customer_format)
        worksheet.merge_range('E9:F9', 'Project Type', customer_header_format)
        worksheet.merge_range('G9:H9', costing_value['project_type'], customer_format)
        if costing_value['date_approve']:
            worksheet.merge_range('E10:F10', 'Confirmation Date', customer_header_format)
            worksheet.merge_range('G10:H10', costing_value['date_approve'], customer_format)
        worksheet.merge_range('A13:I13', '')
        worksheet.set_column('A:A', 40)
        worksheet.set_column('B:B', 15)
        worksheet.set_column('C:C', 15)
        worksheet.set_column('D:D', 15)
        worksheet.set_column('E:E', 15)
        worksheet.set_column('F:F', 15)
        worksheet.set_column('G:G', 15)
        worksheet.set_column('H:H', 15)
        row = 14
        if costing_value["systems"]:
            worksheet.write(row, 0, 'System', table_header_left)
            worksheet.write(row, 1, 'Groups', table_header_right)
            row += 1
            for system in costing_value["systems"]:
                groups = ",".join(system["groups"])
                worksheet.write(row, 0, system["system"], table_row_left)
                worksheet.write(row, 1, groups, table_row_right)
                row += 1
        if costing_value["summary"]:
            row = 14
            worksheet.write(row, 3, 'Summary', table_header_left)
            worksheet.write(row, 4, 'Net Cost', table_header_right)
            worksheet.write(row, 5, 'Land Cost', table_header_right)
            worksheet.write(row, 6, 'Overhead', table_header_right)
            worksheet.write(row, 7, 'Land OH Cost', table_header_right)
            worksheet.write(row, 8, 'Selling Price', table_header_right)
            worksheet.write(row, 9, 'Discount', table_header_right)
            worksheet.write(row, 10, 'Net Price', table_header_right)
            worksheet.write(row, 11, 'Net Profit', table_header_right)
            row += 1
            for summary in costing_value["summary"]:
                worksheet.write(row, 3, summary['summary'], table_row_left)
                worksheet.write(row, 4, summary['net_cost'], table_row_right)
                worksheet.write(row, 5, summary['land_cost'], table_row_right)
                worksheet.write(row, 6, summary['overhead'], table_row_right)
                worksheet.write(row, 7, summary['land_oh_cost'], table_row_right)
                worksheet.write(row, 8, summary['selling_price'], table_row_right)
                worksheet.write(row, 9, summary['discount'], table_row_right)
                worksheet.write(row, 10, summary['net_price'], table_row_right)
                worksheet.write(row, 11, summary['net_profit'], table_row_right)
                row += 1



