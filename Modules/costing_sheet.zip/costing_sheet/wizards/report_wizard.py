from odoo import models


class MaterialReportWizard(models.TransientModel):
    _name = "material.report.wizard"
    _description = "material report wizard button function"

    def print_report(self):
        return self.env.ref('costing_sheet.action_material_line_sheet_report').report_action(self)


class InstallReportWizard(models.TransientModel):
    _name = "install.report.wizard"
    _description = "install report wizard button function"

    def print_report(self):
        return self.env.ref("costing_sheet.action_install_line_sheet_report").report_action(self)
