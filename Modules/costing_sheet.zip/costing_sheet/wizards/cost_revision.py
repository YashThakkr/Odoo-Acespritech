from odoo import fields, models


class CostingVersion(models.TransientModel):
    _name = "cost.revision"
    _description = "create multi version from the same cost sheet"

    reason = fields.Text("Revision Reason", required=True)

    def action_submit(self):
        cost_sheet = self.env['cost.sheet'].browse(self.env.context.get('active_ids'))
        if cost_sheet:
            self.env.cr.execute("select revision from cost_sheet order by id desc limit 1")
            fetch_version = self.env.cr.fetchone()
            if fetch_version:
                revision = int(fetch_version[0]) + 1
                # fetch the systems
                systems = []
                for system in cost_sheet.system_ids:
                    groups = []
                    for group in system.group_ids:
                        groups.append((0, 0, {"name": group.name, "custom": group.custom, "shipping": group.shipping,
                                              "oh": group.oh, "margin": group.margin,
                                              "material_risk": group.material_risk}))
                    systems.append((0, 0, {"name": system.name, "group_ids": groups}))
                self.env["cost.sheet"].create({
                    "name": cost_sheet.name, "revision": revision,
                    "lead_id": cost_sheet.lead_id.id, "project_name": cost_sheet.project_name,
                    "project_type": cost_sheet.project_type, "customer_id": cost_sheet.customer_id.id,
                    "currency_id": cost_sheet.currency_id.id, "validity_date": cost_sheet.validity_date,
                    "notes": cost_sheet.notes, "completion_date": cost_sheet.completion_date,
                    "approved_by": cost_sheet.approved_by.id, "discount": cost_sheet.discount,
                    "discount_approved_by": cost_sheet.discount_approved_by.id,
                    "cost_revision_id": cost_sheet.id, "revision_reason": self.reason,
                    "is_revision": True, "system_ids": systems})
