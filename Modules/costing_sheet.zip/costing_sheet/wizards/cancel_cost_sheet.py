from odoo import  fields, models


class CostSheetCancel(models.TransientModel):
    _name = 'cost.sheet.cancel'
    _description = "Cost Sheet Cancel"

    cost_id = fields.Many2one('cost.sheet', string='Cost Sheet', required=True, ondelete='cascade')

    def action_cancel(self):
        self.cost_id.state ='cancel'
        self.cost_id.approved = False