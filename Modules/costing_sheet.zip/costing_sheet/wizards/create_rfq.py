from odoo import models, fields,api
from odoo.tests import  Form

class ConvertQuotation(models.TransientModel):
    _name = "rfq.generation"
    _description = "RFQ To Generate"
    
    
    vendor_id = fields.Many2one("res.partner", string="Vendor")
    sheet_product_ids = fields.Many2many("product.product", 'product_domain_rel', string="Products Domain", compute="_compute_sheet_product_ids")
    product_ids = fields.Many2many("product.product", string="Products")
        
    @api.depends("vendor_id")
    def _compute_sheet_product_ids(self):
        for rec in self:
            sheet = self.env["material.sheet"].browse(self._context.get("active_id",False))
            rec.sheet_product_ids = sheet.line_ids.mapped("line_ids.product_id.id")
    
    def action_create_rfq(self):
        po_obj = self.env["purchase.order"]
        po_view = 'purchase.purchase_order_form'
        with Form(po_obj,po_view) as po_form:
            po_form.partner_id = self.vendor_id
            for product in self.product_ids:
                with po_form.order_line.new() as line:
                    line.product_id = product
            po_order = po_form.save()
            po_order.material_sheet_id = self._context.get("active_id",False)
        return {
                'name': "Purchase Order",
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'purchase.order',
                'res_id': po_order.id,
            }
                
    