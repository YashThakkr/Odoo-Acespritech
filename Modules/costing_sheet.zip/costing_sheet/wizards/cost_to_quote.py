from odoo import models
from datetime import datetime
import re
from odoo.exceptions import ValidationError


class ConvertQuotation(models.TransientModel):
    _name = "cost.to.quotation"
    _description = "Cost sheet Quotation"

    def create_project(self, cost):
        user_id = self.env.user.id
        if cost.department_id and cost.project_type:
            project = self.env["project.project"].search([("name", "=", cost.project_name)])
            if not project:
                serial = "00001"
                fetch_project = self.env["project.project"].search([("project_year", "=",str(cost.issue_date.year)[2:])])
                if fetch_project:
                    seq = re.search("\d+(?!\d+)$", fetch_project.analytic_account_id.name)
                    if seq:
                        s = int(seq.group()) + 1
                        serial = '{0:05}'.format(s)
                name = f"{str(cost.issue_date.year)[2:]}/{cost.project_type.abbreviation}/{cost.department_id.abbreviation}/{serial}"
                plan_id = self.env['account.analytic.plan'].search([],limit=1)
                if not plan_id:
                    raise ValidationError(_("Analytic Plans not found, Please create at least one."))
                account = self.env["account.analytic.account"].create({"name": name, "active": True,
                                                                       "partner_id": cost.customer_id.id,
                                                                       "company_id": cost.company_id.id,
                                                                       "plan_id": plan_id.id,
                                                                       })
                project = self.env["project.project"].create({"department_id": cost.department_id.id,
                                                              "product_type_id": cost.project_type.id,
                                                              "project_year": str(cost.issue_date.year),
                                                              "name": cost.project_name, "active": True,
                                                              "company_id": cost.company_id.id, "user_id": user_id,
                                                              "label_tasks": "Tasks", "privacy_visibility": "portal",
                                                              "allow_subtasks": False,
                                                              "allow_recurring_tasks": False,"analytic_account_id": account.id})
            if project:
                # subtask
                # project.update({"subtask_project_id": project.id})
                # email
                model_task = self.env["ir.model"].search([("model", "=", "project.task")])
                model_project = self.env["ir.model"].search([("model", "=", "project.project")])
                if model_task and model_project:
                    mail = self.env["mail.alias"].create({"alias_model_id": model_task.id, "alias_user_id": "",
                                                          "alias_defaults": "{'project_id':%s}" % (project.id),
                                                          "alias_parent_model_id": model_project.id,
                                                          "alias_parent_thread_id": project.id,
                                                          "alias_contact": "everyone",
                                                          })
                    if mail:
                        project.update({"alias_id": mail.id})
            return project.id
        return False

    def get_material_lines(self, cost):
        data = []
        self._cr.execute(f"""select mat.id 
                             from material_sheet as mat
                             where mat.cost_id ={cost.id}
                            """)
        materials = self._cr.fetchall()
        for material in materials:
            material_id = material[0]
            lines = self.env["material.sheet.line"].search([("material_id", "=", material_id)])
            for line in lines:
                self._cr.execute(f"""select  mat_line.system_id,mat_line.group_id,json_agg(json_build_object('quote_description',
                                    mat_data.quote_description,'quote_qty',mat_data.quote_qty,'quote_unit',
                                    mat_data.quote_unit,'unit_price',mat_data.final_total,
                                    'product',mat_data.product_id,'cs_brand',mat_data.cs_brand,'quote_model',mat_data.quote_model)) as products  
                                    from material_sheet_line as mat_line 
                                    right join material_line_data as mat_data 
                                    on mat_data.material_sheet_id = mat_line.id
                                    where mat_data.material_sheet_id={line.id}
                                    group by (mat_line.system_id,mat_line.group_id)""")
                lines_data = self._cr.fetchall()
                for d in lines_data:
                    system = self.env["system.system"].search([("id", "=", d[0])])
                    group = self.env["system.group"].search([("id", "=", d[1])])
                    data.append({"system": system.name, "group": group.name, "products": d[2]})
        return data

    def get_install_lines(self, cost):
        data = []
        installs = self.env["install.sheet"].search([('cost_id','=',cost.id)])
        for install in installs.mapped("line_ids"):
            #===================================================================
            # for line in lines:
            #     self._cr.execute(f"""select line.system_id,json_agg(json_build_object('description',
            #                                    data.description,'qty',data.qty,'unit',
            #                                    data.unit,'unit_price',data.unit_price,
            #                                    'product',data.product_id)) as products
            #                                    from install_sheet_line as line
            #                                    right join (select  installation_line_id,description,qty,
            #                                    unit,discount,unit_price,product_id from install_line_data) as data
            #                                    on data.installation_line_id = line.id
            #                                    where data.installation_line_id ={line.id}
            #                                    group by (line.system_id)""")
            #     lines_data = self._cr.fetchall()
            #===================================================================
            total_price = 0
            for rec in install.mapped("install_line_data"):
                total_price += rec.total_selling_price
            qty = install.quote_qty or 1
            data.append(
                {"system": install.system_id.name + '  -- Installation --', "products": [{'quote_description': install.quote_description, 'quote_qty': install.quote_qty,
                  'product_brand': install.brand_id.id,'quote_unit': install.quote_unit.id, 'unit_price': total_price/qty, 'product': install.quote_product_id.id, 'quote_model': install.quote_model}]})
        return data

    @staticmethod
    def create_lines(lines):
        data = []
        current_system = 'abd'
        for line in lines:
            if current_system != line["system"]:
                data.append((0, 0, {"name": line["system"], "display_type": "line_section"}))
                current_system = line["system"]
            if line.get("group"):
                data.append((0, 0, {"name": line["group"], "display_type": "line_note"}))
            for product in line["products"]:
                data.append((0, 0, {"name": product.get('description',False) or product.get('quote_description',False), "price_unit": product['unit_price']/(product.get('quote_qty') or 1),
                            "product_id": product['product'],
                            "product_brand": product.get('cs_brand',False) or product.get('product_brand',False),
                            "part_number": product.get('quote_model',False),
                            # uncomment todo if you wanna pass cs_model that coming from metrial sheet lines
                            # "part_number": product.get('quote_model',False) or product.get('cs_model',False),
                            "product_uom_qty": product.get('quote_qty',0)}))
        return data

    def action_submit(self):
        cost = self.env["cost.sheet"].browse(self.env.context.get('active_id'))
        user = self.env.user
        company_id = cost.company_id.id
        if cost:
            partner_id = cost.customer_id.id
            # filter in the material
            materials = self.get_material_lines(cost)
            lines = self.create_lines(materials)
            print ("\n material lines ::::::::::::: ",lines)
            # filter in the install
            installs = self.get_install_lines(cost)
            lines.extend(self.create_lines(installs))
            print ("\n intallation lines ++++++++++ ",lines)
            #projects
            project = self.create_project(cost)
            if project:
                cost_currency_pricelist = self.env['product.pricelist'].search([('currency_id', '=', cost.currency_id.id), ('company_id', '=', company_id)],limit=1)
                data = {"origin": cost.name, "state": "draft", "user_id": user.id, "partner_id": partner_id,
                        "partner_invoice_id": partner_id, "partner_shipping_id": partner_id,
                        "currency_id": cost.currency_id.id,
                        "note": cost.notes, "company_id": company_id, "project_id": project,
                        "order_line": lines,"cost_id":cost.id}
                if cost_currency_pricelist:
                    data.update({'pricelist_id':cost_currency_pricelist.id})
                order = self.env["sale.order"].create(data)
                